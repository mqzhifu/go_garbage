# GameOnlineBattleFramework

## Demos Specification

- 登陆场景：assets\GameOnlineBattleFrameworkDemo\Scenes\Login.scene 

- 同步场景：assets\GameOnlineBattleFrameworkDemo\Scenes\Game.scene 

1. 手动登陆模式：
   1. 打开Login.scene场景，Hierarchy中选中Room，Inspector中设置服务器IP地址，服务器Port端口号，Uid可以保持默认，在游戏启动后的UI界面设置，确认AutoLogin没有被勾选；
   2. 运行游戏，在输入框内输入任意Uid，然后点击Login，如果登陆成功，窗口将会显示Login success，继续点击Match按钮，窗口将会显示Matching others，进入匹配等待状态；
      - 如果窗口显示 login failed / match failed时，请检查IP地址，服务器Port是否正确，检查服务器是否运行正常；
   3. 当满足同步开始的人数(默认为2)，服务器会通知进入同步场景，玩家会进入同步场景，手机端通过虚拟按钮控制移动，PC端通过上下左右按键控制移动；
   4. 断线重连功能在手动模式下，无论是网络问题导致断线还是关闭了窗口导致断线，重新回到登陆场景的时候，请输入之前登录时的Uid，否则无法正常重连；
      - 当有玩家断线时，其他玩家等待该玩家恢复的时间为30秒，30秒内断线的玩家还未重连，本场游戏关闭；
2. 自动登陆模式：
   1. 打开Login.scene场景，Hierarchy中选中Room，Inspector中设置服务器IP地址，服务器Port端口号，设置Uid(不同客户端的Uid请勿重复！)，确认AutoLogin被勾选；
   2. 运行游戏，会自动完成登陆和进入匹配等待状态；
      - 如果窗口显示 login failed / match failed时，请检查IP地址，服务器Port是否正确，检查服务器是否运行正常；
   3. 当满足同步开始的人数(默认为2)，服务器会通知进入同步场景，玩家会进入同步场景，手机端通过虚拟按钮控制移动，PC端通过上下左右按键控制移动；
   4. 自动登陆模式下，直接重启即可自动重连；
      - 当有玩家断线时，其他玩家等待该玩家恢复的时间为30秒，30秒内断线的玩家还未重连，本场游戏关闭；

## SDK Specification

### Scripts explain

- Room.ts
  - 必须挂在场景中，并且inspector面板提供了IP，Port，Uid的设置入口，提供了AutoLogin的选项；
- NetHelper.ts
  - 提供登陆，匹配，申请重连等接口和重要事件回调；
- Protocol.ts
  - 提供了回调方法的参数类型；

## Server Deploy in GO Env Machine

1. 创建一个文件夹frame_sync，并且设置777权限，并且新建logs文件夹，logs内新建app backend frontend service四个文件夹，并且设置777权限；

```
mkdir frame_sync
sudo chmod 777 /home/.../frame_sync

cd frame_sync
mkdir logs
sudo chmod 777 /home/.../frame_sync/logs

cd logs
mkdir app
mkdir backend
mkdir frontend
mkdir service
sudo chmod 777 /home/.../frame_sync/logs/app
sudo chmod 777 /home/.../frame_sync/logs/backend
sudo chmod 777 /home/.../frame_sync/logs/frontend
sudo chmod 777 /home/.../frame_sync/logs/service
```

2. 下载服务器源代码到frame并解压

```
cd frame_sync
wget https://github.com/mqzhifu/frame_sync/archive/refs/tags/v0.0.2.zip
unzip v0.0.2.zip
```

3. 下载zlib，放在frame_sync文件夹内；

```
cd /home/.../frame_sync
git clone https://github.com/mqzhifu/zlib.git
```

4. 运行服务器

```
go run main.go local xxx.xxx.xxx.xxx httpPort WsPort TcpPort /home/.../frame_sync/logs 
```

