import { _decorator, Component, Node, Vec3, log, tween, Prefab, instantiate, Canvas, Label, Layers, CameraComponent, warn, sys, systemEvent, SystemEvent, EventKeyboard } from 'cc';
import { NetHelper } from '../../../extensions/GameOnlineBattleFramework/scripts/NetHelper';
import { Operation, ReconnectState } from '../../../extensions/GameOnlineBattleFramework/scripts/Protocol';
import { NetManager } from './NetManager';
const { ccclass, property } = _decorator;
const PLAYERMOVEINTERNAL = 3;
/** 按键 */
export enum KeyName {
    leftArrow = 37,
    upArrow = 38,
    rightArrow = 39,
    downArrow = 40
}

const MOVEANIMINTERVAL = 0.1;
const MOVEANIMRECONNINTERBAL = 0.01;

@ccclass('Game')
export class Game extends Component {
    /** 主相机 */
    @property({type:Node})
    private mainCamera?: Node;
    /** 代表玩家的prefab */
    @property({type:Prefab})
    private playerPrefab?: Prefab;
    /** UI的摄像机 layer = UI_2D */
    @property({type:Canvas})
    private uiCanvas?: Canvas;

    /** 玩家数组，存储玩家对应的cube */
    private players: Map<number, Node> = new Map;
    /** 玩家们的起始位置 */
    private playersStartPos: Map<number, Vec3> = new Map;
    /** 玩家们的目标位置 */
    private playersDestination: Map<number, Vec3> = new Map;
    /** 玩家移动步长 */
    private invertal: number = PLAYERMOVEINTERNAL;
    /** 玩家UI显示 */
    private playersLabel: Map<number, Node> = new Map;
    /** 玩家操作列表 */
    private playersCommandsList: Map<number, number[]> = new Map;
    /** cube移动动画执行间隔 */
    private moveAnimInterval?: number;

    onLoad() {
        // 绑定键盘按下弹起事件
        systemEvent.on(SystemEvent.EventType.KEY_DOWN, this.OnKeyDown, this);
    }
    /**
     * 键盘按键按下
     * @param event 
     * @returns 
     */
     private OnKeyDown(event: EventKeyboard): void {
        NetHelper.sendFrame(event.keyCode);
    }
    /** 按下up button  */
    private onTouchUpBtn(): void {
        NetHelper.sendFrame(KeyName.upArrow);
    }
    /** 按下down button */
    private onTouchDownBtn(): void {
        NetHelper.sendFrame(KeyName.downArrow);
    }
    /** 按下left button */
    private onTouchLeftBtn(): void {
        NetHelper.sendFrame(KeyName.leftArrow);
    }
    /** 按下right button */
    private onTouchRightBtn(): void {
        NetHelper.sendFrame(KeyName.rightArrow);
    }

    start() {
        this.initilization();
    }
    
    public initilization(): void {
        this.initPlayer();
        this.initMainCamera();
        NetHelper.onRecvFrame(this.playerOperation.bind(this));
        NetHelper.onResumeFrameSync(this.onGameContinue.bind(this));
        if(NetHelper.getUserStatus().reconnectState != ReconnectState.recovering) {
            NetHelper.readyFrameSync();
            this.moveAnimInterval = MOVEANIMINTERVAL;
        } else{
            this.moveAnimInterval = MOVEANIMRECONNINTERBAL;
        }
    }  
    private uiPos = new Vec3;
    /** player ui label 跟随玩家 */
    private uiLabelFolloPlayer(): void {
        if (this.players != undefined && this.playersLabel != undefined && this.mainCamera != undefined){
            if(this.players.size > 0){
                let num = NetHelper.getOnlineUserNum();
                let player: Node;
                let label: Node;
                for (let index = 0; index < num; index++) {
                    const playerId = NetHelper.getIndexedUserId(index);
                    if(this.players.get(playerId) == undefined || this.playersLabel.get(playerId) == undefined){ continue; }
                    player = this.players.get(playerId)!;
                    player.getWorldPosition(this.uiPos);
                    label = this.playersLabel.get(playerId)!;
                    this.mainCamera.getComponent(CameraComponent)!.convertToUINode(this.uiPos,label.parent!,this.uiPos);
                    label.position = this.uiPos;
                }
            }
        }         
    }
    /** 初始化主相机的位置 */
    private initMainCamera(): void {
        if (this.mainCamera != undefined) {
            let initCameraPos: Vec3 = new Vec3;
            let playerId = NetHelper.getLocalPlayerId();
            Vec3.add(initCameraPos, this.players.get(playerId)!.getWorldPosition() as Vec3, this.offsetPos);
            this.mainCamera.setWorldPosition(initCameraPos);
        }
    }
    update(deltaTime: number) {

        this.checkRecoverStatus();

        this.handleCommandList(deltaTime);

    }
    lateUpdate(deltaTime: number){

        this.mainCameraFollow(deltaTime);

        this.uiLabelFolloPlayer();
    }
    
    onDestroy(){
        // 绑定键盘按下弹起事件
        systemEvent.off(SystemEvent.EventType.KEY_DOWN, this.OnKeyDown, this);
    }

    private onGameContinue(): void {
        log("[Game]Game continue !");
    }
    private playerOperation(data: Operation): void {
        //log("playerId:", data.playerId,"command index:", data.value);
        if(!this.playersCommandsList.has(data.playerId)) { return; }
        this.playersCommandsList.get(data.playerId)?.push(Number(data.value));
    }

    private commandExecuteTimer: number = 0;

    private handleCommandList(dt: number): void {
        // 收到的操作指令进行平滑移动动画
        this.commandExecuteTimer += dt;
        if (this.commandExecuteTimer > this.moveAnimInterval!) {
            let num = NetHelper.getOnlineUserNum();
            for (let index = 0; index < num; index++) {
                let playerId = NetHelper.getIndexedUserId(index);
                if(!this.playersCommandsList.has(playerId)){ continue; }
                const commands = this.playersCommandsList.get(playerId)!;
                if (commands.length > 0) {
                    let key = commands.shift() as number;
                    switch (key) {
                        case KeyName.upArrow:
                            this.moveAnim(this.playersDestination.get(playerId) as Vec3,
                                this.playersStartPos.get(playerId) as Vec3,
                                new Vec3(0, 0, -this.invertal),
                                this.players.get(playerId) as Node);
                            break;
                        case KeyName.downArrow:
                            this.moveAnim(this.playersDestination.get(playerId) as Vec3,
                                this.playersStartPos.get(playerId) as Vec3,
                                new Vec3(0, 0, this.invertal),
                                this.players.get(playerId) as Node);
                            break;
                        case KeyName.leftArrow:
                            this.moveAnim(this.playersDestination.get(playerId) as Vec3,
                                this.playersStartPos.get(playerId) as Vec3,
                                new Vec3(-this.invertal, 0, 0),
                                this.players.get(playerId) as Node);
                            break;
                        case KeyName.rightArrow:
                            this.moveAnim(this.playersDestination.get(playerId) as Vec3,
                                this.playersStartPos.get(playerId) as Vec3,
                                new Vec3(this.invertal, 0, 0),
                                this.players.get(playerId) as Node);
                            break;
                        default:
                            break;
                    }
                    // 每一次执行了移动动画后，都把终点位置当作下一次的起点位置
                    this.playersStartPos.get(playerId)?.set(this.playersDestination.get(playerId) as Vec3);
                }
            }
            // 重置操作指令执行计时器
            this.commandExecuteTimer = 0;
        }
    }

    /**
     * 移动平滑
     * @param des 移动终点  
     * @param start 移动起点
     * @param moveDir 移动的方向步长
     * @param obj 具体执行移动动画的对象
     */
    private moveAnim(des: Vec3, start: Vec3, moveDir: Vec3, obj: Node): void {
        Vec3.add(des, start, moveDir);
        //log("[Game]startPos:" + start, "endPos:" + des);
        let deltaL = Vec3.distance(start, des);
        let time = deltaL / 2;
        tween(obj)
            .to(time, { position: des }).start();
    }

    /**
     * 初始化玩家
     * @param id 玩家ID
     */
    private initPlayer(): void {
        let userNum :number = NetHelper.getOnlineUserNum();
        log("num2:",userNum);
        // 玩家少于2，异常情况      
        if (userNum < 2) {
            warn("plyaer num less than 2 , error , return to Login scene.");
        }
        // 初始化在线玩家列表里的玩家
        if (userNum > 0) {
            // 根据在线玩家列表人数，初始化
            let cube :Node;
            let playerCube :Node;
            let playerLabel: Node;
            for (let index = 0; index < userNum; index++) {
                // 获取玩家ID
                const playerId = NetHelper.getIndexedUserId(index);
                // 初始化玩家操作列表
                this.playersCommandsList.set(playerId, new Array<number>());
                if(this.playerPrefab == undefined) { return; }
                // 初始化生成cube
                cube = instantiate(this.playerPrefab);
                cube.setParent(this.node);
                cube.setPosition(new Vec3(0 + index * 2, 0.5, 0 + index * 2));
                log("[Game]cube", index, "position:", cube.getPosition());
                // 初始化 player相关
                this.players.set(playerId, cube);
                playerCube = this.players.get(playerId) as Node;             
                this.playersStartPos.set(playerId, playerCube.getPosition()!);
                this.playersDestination.set(playerId, playerCube.getPosition()!);
                // 初始化 player的ui label
                playerLabel = new Node(playerId.toString());
                playerLabel.addComponent(Label).string = playerId.toString();
                if(this.uiCanvas == undefined) { return; }
                playerLabel.setParent(this.uiCanvas.node);
                playerLabel.layer = Layers.Enum.UI_2D;
                this.playersLabel.set(playerId, playerLabel);
                log("[Game]PlayerId", playerId, "init finished");
            }
        }
        log("[Game]I'm PlayerId", NetHelper.getLocalPlayerId(), "init finished");
    }
    
    /** 玩家与相机之间的offset */
    private offsetPos: Vec3 = new Vec3(-20, 20, 20);
    /** 当玩家移动后，主摄像机所在的位置 */
    private updatedCameraPos: Vec3 = new Vec3;
    /** 主摄像机应该缓动的终点位置 */
    private finalPos = new Vec3;
    /**
     * 主摄像机follow玩家
     */
    private mainCameraFollow(dt: number): void {
        if (this.mainCamera != undefined && NetHelper.getLocalPlayerId() != -1) {       
            Vec3.add(this.updatedCameraPos, this.players.get(NetHelper.getLocalPlayerId())!.getWorldPosition(), this.offsetPos);
            Vec3.lerp(this.finalPos, this.mainCamera.getWorldPosition(), this.updatedCameraPos, dt);
            this.mainCamera.setWorldPosition(this.finalPos);
        }
    }
    /**
    * 检测游戏重连恢复情况
    */
    private checkRecoverStatus(): void {
        if (NetHelper.getUserStatus().reconnectState != ReconnectState.recovering)
            return;
            if(!NetManager.getInstance().emptyHistorPlayerOperations()){
                this.playerOperation(NetManager.getInstance().getHistoryPlayerOperations());
            }
        // 处于正在恢复状态，并且commands全部执行完毕
        if (NetHelper.getUserStatus().reconnectState == ReconnectState.recovering && NetManager.getInstance().emptyHistorPlayerOperations()) {
            NetHelper.getUserStatus().reconnectState = ReconnectState.recovered;
            this.moveAnimInterval = MOVEANIMINTERVAL;
            NetHelper.handleHistoryFramesFinished();
        }
    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.0/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.0/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.0/manual/en/scripting/life-cycle-callbacks.html
 */
