import { _decorator, Component, log, director, Button, EditBox, RichText } from 'cc';
import { NetHelper } from '../../../extensions/GameOnlineBattleFramework/scripts/NetHelper';
import { MatchGroup, NetErrorType, Operation, RemotePlayerOffline, OfflinePlayerResume, RoomHistroyFrames, RoomInfo,InitRoom} from '../../../extensions/GameOnlineBattleFramework/scripts/Protocol';
import { Room } from '../../../extensions/GameOnlineBattleFramework/scripts/Room';
import { NetManager } from './NetManager';

const { ccclass, property} = _decorator;

const ERRORHEADER = '<color=#ff0101>Error</color><color=#000000> :</color>';
const NORMALHEADER = '<color=#00ff00>State</color><color=#000000> :</color>';
export enum logType {
    error = 1,
    normal = 2,
}

@ccclass('Login')
export class Login extends Component {
    
    @property(Button)
    public loginBTN?: Button;

    @property(Button)
    public matchBTN?: Button;

    @property(EditBox)
    public inputField?: EditBox;

    @property(RichText)
    public logDisplay?:RichText;

    @property(RichText)
    public showUID?:RichText;

    @property(Room)
    public room?:Room;
    
    start () {
        NetHelper.onNetError(this.httpGetError.bind(this));
        NetHelper.onJoinRoom(this.loginIn.bind(this));
        NetHelper.onReconnRoom(this.reconnRoom.bind(this));
        NetHelper.onMatchGroup(this.matchSuccess.bind(this));
        NetHelper.onRecvFrame(this.roomHistoryOperation.bind(this));
        NetHelper.onHistoryFrames(this.roomHistory.bind(this));
        NetHelper.onOfflinePlayerResume(this.otherPlayerResume.bind(this));
        NetHelper.onRemotePlayerOffline(this.otherPlayerOffline.bind(this));
        if(this.room!.autoLogin) {
            this.loginBTN!.node.active = false;  
            this.matchBTN!.node.active = false; 
            this.inputField!.node.active = false;
        }
    }

    public onClickLoginBTN(): void {
        let str = this.inputField!.string;
        if(str != '')
            this.room!.uid = Number(str);
        NetHelper.readyJoinRoom(this.room!.ip!, this.room!.port!, this.room!.uid!);
        this.loginBTN!.node.active = false;
        this.inputField!.node.active = false;
        this.showUID!.string = 'UID: '+ NetHelper.getLocalPlayerId();
        NetHelper.joinRoom();
    }

    public onClickMatchBTN(): void {
        this.matchBTN!.node.active = false;
        this.onLogDisplay(logType.normal, 'matching others');
        NetHelper.matchGroup();
    }

    private onLogDisplay(type: number, text: string): void {
        switch(type) {
            case logType.error:
                this.logDisplay!.string = ERRORHEADER + ' <color=#ff0101>' + text + '</color>';
                break;
            case logType.normal:
                this.logDisplay!.string = NORMALHEADER + ' <color=#00ff00>' + text + '</color>';
                break;
        }
    }

    private httpGetError(data: NetErrorType): void {
        switch (data) {
            case NetErrorType.getWebsocketURLFailed:
                this.onLogDisplay(logType.error, "login failed");
                log("get websocket URL failed");
                this.loginBTN!.node.active = false;
                break;
            case NetErrorType.getTokenFailed:
                this.onLogDisplay(logType.error, "login failed");
                log("get token failed");
                this.loginBTN!.node.active = false;
                break;
            case NetErrorType.joinRoomFailed:
                this.onLogDisplay(logType.error, "login failed");
                log("login failed");
                break;
            case NetErrorType.matchSignFailed:
                this.onLogDisplay(logType.error, "match failed");
                log("match failed");
                break;
            case NetErrorType.webscoketConnectClosed:
                log("webscoket connect closed");
                break;
            case NetErrorType.websocketConnectError:
                log("websocket connect error");
                break;
            case NetErrorType.heartBeatTimeout:
                log("heart beat timeout");
                break;
            case NetErrorType.RTTOver:
                log("RTT timeout");
                break;
            default:
                break;
        }
    }
    private loginIn(data: InitRoom): void {
        console.log("[loginIn]:", data.code);
        this.onLogDisplay(logType.normal, "login success");
        this.matchBTN!.node.active = true;

        if(this.room!.autoLogin) {
            this.matchBTN!.node.active = false;
            this.onLogDisplay(logType.normal, 'matching others');
            this.showUID!.string = "UID: " + NetHelper.getLocalPlayerId().toString();
        }
    }
    private reconnRoom(data: RoomInfo): void {
        //this.onLogDisplay(logType.normal, "reconnect room success");
        console.log("[reconnRoom]:", data.roomId);
    }
    private matchSuccess(data : MatchGroup): void {
        console.log("[matchSuccess]roomid:", data.roomId);
        this.logDisplay!.string = '';
        director.loadScene("Game");
    }
    private roomHistoryOperation(data: Operation): void {
        console.log("id:",data.playerId,"value:",data.value);
        NetManager.getInstance().setPlayerHistoryCommands(data.playerId, Number(data.value));
        NetManager.getInstance().addHistoryPlayerOperations(data);
    }
    private roomHistory(data: RoomHistroyFrames): void {
        director.loadScene("Game");
    }
    private otherPlayerResume(data: OfflinePlayerResume): void {
        console.log("[otherPlayerResume]:", data.playerId);
    }
    private otherPlayerOffline(data: RemotePlayerOffline): void {
        console.log("[otherPlayerOffline]:", data.playerId);
    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.0/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.0/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.0/manual/en/scripting/life-cycle-callbacks.html
 */
