import { NetHelper } from '../../../extensions/GameOnlineBattleFramework/scripts/NetHelper';
import { Operation } from '../../../extensions/GameOnlineBattleFramework/scripts/Protocol';

export class NetManager {

    private static instance: NetManager | undefined;
    public static getInstance() : NetManager
    {
        if(this.instance == undefined)
        {
            this.instance = new NetManager;
        }
        return this.instance;
    }

    private _historyCommands: Map<number,number[]> = new Map;

    private _historyPlayerOperations: Operation[] = [];
    
    public addHistoryPlayerOperations(v : Operation) {
        this._historyPlayerOperations.push(v);
    }
    public getHistoryPlayerOperations() : Operation {
        return this._historyPlayerOperations.shift()!;
    }
    public emptyHistorPlayerOperations(): boolean {
        if(this._historyPlayerOperations.length == 0)
            return true;
        else
            return false;
    }
    public getPlayerHistoryCommands(playerId: number) : number[] | undefined {
        if(!this._historyCommands.has(playerId)){ return; }
        return this._historyCommands.get(playerId);
    }
    public setPlayerHistoryCommands(playerId: number, commands: number): void {
        if(this._historyCommands.has(playerId)) {
            let playerCommands = this._historyCommands.get(playerId);
            playerCommands!.push(commands);
            console.log("has,",playerId,"value",commands);
        } else {
            this._historyCommands.set(playerId,new Array<number>());
            let playerCommands = this._historyCommands.get(playerId);
            playerCommands!.push(commands);
            console.log("hasnot,",playerId,"value",commands);
        }

    }
    public isHistoryCommandsEmpty(): boolean {
        let num = NetHelper.getOnlineUserNum();
        for (let index = 0; index < num; index++) {
            const playerId = NetHelper.getIndexedUserId(index);
            if(this.getPlayerHistoryCommands(playerId)?.length != 0)
            {
                return false;
            }
        }
        return true;
    }   
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.0/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.0/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.0/manual/en/scripting/life-cycle-callbacks.html
 */
