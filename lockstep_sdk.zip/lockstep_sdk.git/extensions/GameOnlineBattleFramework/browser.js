'use strict';

// 扩展内定义的方法
exports.methods = {
    registerSuccess() {
        console.log('Hello Game Online Battle Framwork');
    },
};

// 当扩展被启动的时候执行
exports.load = function() {};

// 当扩展被关闭的时候执行
exports.unload = function() {};

// html 文本
exports.template = '';
// 样式文本
exports.style = '';
// 渲染后 html 选择器
exports.$ = {};
// 面板上的方法
//exports.methods = {};
// 面板上触发的事件
exports.listeners = {
    listen() {

    },
};

// 当面板渲染成功后触发
exports.ready = async function() {
    console.log("render success");
};
// 尝试关闭面板的时候触发
exports.beforeClose = async function() {};
// 当面板实际关闭后触发
exports.close = async function() {};