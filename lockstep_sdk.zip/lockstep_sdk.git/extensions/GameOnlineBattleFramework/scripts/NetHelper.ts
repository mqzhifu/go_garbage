import { NetSyestem } from "./NetSystem";
import { UserStatus } from "./Protocol";

export class NetHelper {
    /**
     * 用户状态
     */
    public static getUserStatus(): UserStatus {
        return NetSyestem.getInstance().userStatus;
    }
    /**
     * 加入房间前准备设置
     * @param ip 服务器ip
     * @param httpPort 服务器端口
     * @param uid 玩家UID
     */
    public static readyJoinRoom(ip: string, httpPort: number, uid: number): void {
        NetSyestem.getInstance().getTokenServerURL(ip, httpPort, uid);
        NetSyestem.getInstance().getHttpServerURL(ip, httpPort);
    }
    /**
     * 申请加入房间
     */
    public static joinRoom(): void {
        NetSyestem.getInstance().joinRoom();
    }
    /**
     * 申请重连
     */
    public static reconnRoom(): void {
        NetSyestem.getInstance().rejoinRoom();
    }
    /**
     * 申请匹配
     */
    public static matchGroup(): void {
        NetSyestem.getInstance().matchGroup();
    }
    /**
     * 取消匹配
     */
    public static cancelMatch(): void {
        NetSyestem.getInstance().cancelMatch();
    }
    /**
     * 帧同步前的准备完毕
     */
    public static readyFrameSync(): void {
        NetSyestem.getInstance().readyFrameSync();
    }
    /**
     * 处理全部帧同步历史操作完毕
     */
    public static handleHistoryFramesFinished(): void {
        NetSyestem.getInstance().historyFramesFinished();
    }
    /**
     * 发送帧同步数据
     * @param num 要同步的操作指令值
     */
    public static sendFrame(num: number): void {
        NetSyestem.getInstance().syncCommand(num);
    }
    /**
     * 获取同一匹配房间的在线用户数量
     */
    public static getOnlineUserNum(): number {
        return NetSyestem.getInstance().getOnlineUserNum();
    }
    /**
     * 根据index获取用户ID
     * @param index 用户ID
     */
    public static getIndexedUserId(index: number): number {
        return NetSyestem.getInstance().getIndexedUserId(index);
    }
    /**
     * 获取本地PlayerID
     */
    public static getLocalPlayerId(): number {
        return NetSyestem.getInstance().localPlayerId;
    }
    /**
     * Net error 绑定回调接口
     * @param callback 用户自定义回调函数
     * @description net error 后，用户获得该错误通知，用户可以根据Protocol.NetErrorType来判断具体错误类型
     * @example
     * ```typescript
     * userCutsomCallback(data: string): void {  
     *   data : Protocol.NetErrorType
     * } 
     * // 绑定自定义callback
     * NetSyestem.onNetError(userCustomCallback.bind(this));
     * ```
     */
    public static onNetError(callback: Function): void {
       NetSyestem.getInstance().onNetError(callback); 
    }
    /**
     * 加入房间成功 绑定回调接口
     * @param callback 用户自定义回调函数
     * @description 加入房间成功后，用户可以获取房间信息
     * @example
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: InitRoom): void{
     *     // 根据data类型做具体操作
     * } 
     * // 绑定自定义callback
     * NetSyestem.onJoinRoom(userCustomCallback.bind(this));
     * ```
     */
    public static onJoinRoom(callback: Function): void {
        NetSyestem.getInstance().onJoinRoom(callback);
    }
    /**
     * 重连申请结果 绑定回调函数接口
     * @param callback 用户自定义回调函数
     * @description 重连后会收到服务器推送的历史房间信息 roomInfo
     * @example
     * // 用户自定义callback
     * userCutsomCallback(data:  RoomInfo): void {
     * // dosomething ...
     * } 
     * // 绑定自定义callback
     * NetSyestem.onRejoinRoom(userCustomCallback.bind(this));
     */
    public static onReconnRoom(callback: Function): void {
        NetSyestem.getInstance().onRejoinRoom(callback);
    }
    /**
     * 匹配结果 绑定回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 完成匹配后
     * @example
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: MatchGroup):void{
     * // dosomething ...
     * } 
     * // 绑定自定义callback
     * NetSyestem.onMatchGroup(userCustomCallback.bind(this));
     * ```
     */
    public static onMatchGroup(callback: Function): void {
        NetSyestem.getInstance().onMatchGroup(callback);
    }
    /**
     * 开始帧同步 绑定回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 开始帧同步
     * @example
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: StartFrameSync):void{
     *  // dosomething ...
     * } 
     * // 绑定自定义callback
     * NetSyestem.onStartFrameSync(userCustomCallback.bind(this));
     * ```
     */
    public static onStartFrameSync(callback: Function): void {
        NetSyestem.getInstance().onStartFrameSync(callback);
    }
    /**
     * 服务器推送房间历史 绑定回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 完成接收全部房间历史操作后，用户通过该回调可以获得全部房间历史操作
     * @example 
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: RoomHistroyFrames):void{
     *  // 根据data类型做具体操作
     * } 
     *  // 绑定自定义callback
     * NetSyestem.onHistoryFrames(userCustomCallback.bind(this));
     * ```
     */
    public static onHistoryFrames(callback: Function): void {
        NetSyestem.getInstance().onHistoryFrames(callback);
    }
    /**
     * 有其他玩家恢复游戏 绑定回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当有玩家恢复游戏时，通过该接口绑定的回调函数将会响应，用户可以通过该回调函数获取信息
     * @example 
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: OfflinePlayerResume):void{
     *  // 根据data类型做具体操作
     * } 
     *  // 绑定自定义callback
     * NetSyestem.onOfflinePlayerResume(userCustomCallback.bind(this));
     * ```
     */
    public static onOfflinePlayerResume(callback: Function): void {
        NetSyestem.getInstance().onOfflinePlayerResume(callback);
    }
    /**
     * 有其他玩家掉线 绑定回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当有玩家掉线的时候，通过该接口绑定的回调函数将会响应，用户可以通过该回调函数获取信息
     * @example
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: RemotePlayerOffline): void {
     *  // 根据data类型做具体操作
     * } 
     *  // 绑定自定义callback
     * NetSyestem.onRemotePlayerOffline(userCustomCallback.bind(this));
     * ```
     */
    public static onRemotePlayerOffline(callback: Function): void {
        NetSyestem.getInstance().onRemotePlayerOffline(callback);
    }
    /**
     * 游戏继续 绑定回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当游戏继续的时候，通过该接口绑定的回调函数将会响应，用户可以通过该回调函数得知消息
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback():void {
     *  // 具体操作
     * } 
     *  // 绑定自定义callback
     * NetSyestem.onFrameSyncResume(userCustomCallback.bind(this));
     * ```
     */
    public static onResumeFrameSync(callback: Function): void {
        NetSyestem.getInstance().onResumeFrameSync(callback);
    }
    /**
     * 服务器推送逻辑帧 绑定回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当服务器每次同步过来逻辑帧时，通过该接口绑定的回调函数将会响应，用户可以通过该回调函数得知收到的玩家的操作
     * ```typescript
     * // 用户自定义callback
     * userCustomCallback(data: Operation): void {
     *  // 具体操作
     * }
     *  // 绑定自定义callback
     * NetSyestem.onRecvFrame(userCustomCallback.bind(this));
     * ```
     */
    public static onRecvFrame(callback: Function): void {
        NetSyestem.getInstance().onRecvFrame(callback);
    }
    /**
     * 绑定 服务器推送了异常帧号的逻辑帧 回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当服务器同步逻辑帧时，收到了异常帧号的逻辑帧数据，用户可以通过该回调函数得知该异常数据具体内容
     * ```typescript
     * // 用户自定义callback
     * userCustomCallback(data: RecvFrame): void {
     *  // 具体操作
     * }
     *  // 绑定自定义callback
     * NetSyestem.onRecvUnknowFrame(userCustomCallback.bind(this));
     * ```
     */
    public static onRecvUnkonwFrame(callback: Function): void {
        NetSyestem.getInstance().onRecvUnknowFrame(callback);
    }
}