import { error, log, sys, warn } from 'cc';
import { MatchGroup, NetErrorType, InitRoom, LoginState, MatchState, Operation, RemotePlayerOffline, OfflinePlayerResume, Protocol, RoomHistroyFrames, RoomInfo, ReconnectState, ServerPong, SyncDataType, SyncMode, TokenState, UserStatus, WsURLState, RecvFrame, StartFrameSync, } from './Protocol';

const UNDEFENEDNUMBER = -1;
const UNDEFENEDSTRING = '';
const HEARTBEATTHREHOLDVALUESTARDARD = 8;
const HEARTBEATTIMERDEFAULTVALUE = 0;
const RTTDEFAULTVALUE = 3000;
const RTTDEFAULTTHREHOLDTIMES = 2;
const XMLHTTPREQUESTSUCCESS = 200;

export enum XMLHttpRequestReadyState {
    /** 代理被创建，但尚未调用 open() 方法 */
    UNSENT = 0, 
    /** open() 方法已经被调用 */ 
    OPENED = 1,
    /** send() 方法已经被调用，并且头部和状态已经可获得 */
    HEADERS_RECEIVED = 2,
    /** 下载中,responseText 属性已经包含部分数据 */
    LOADING = 3,
    /** 下载操作已完成 */
    DONE = 4,
}
    /**
     * 建立连接，断开连接，断线重连，发送消息，接收消息，存放网络相关数据
     */
export class NetSyestem {

    private static instance: NetSyestem;
    /** 单例模式 */
    public static getInstance(): NetSyestem {
        if (this.instance == undefined) {
            this.instance = new NetSyestem();
        }
        return this.instance;
    }
    /** 清理单例 */
    public static desInstance() {
        if (this.instance != undefined) {
            this.instance = undefined!;
        }
    }
    /** 同步模式 */
    private _syncMode?: SyncMode;
    public set syncMode(syncMode: SyncMode) {
        this._syncMode = syncMode;
    }
    public get syncMode(): SyncMode {
        if(this._syncMode != undefined)
            return this._syncMode;
        return SyncMode.lockstep;
    }
    /** 同步数据格式 */
    private _syncDataType?: SyncDataType;
    public set syncDataType(dataType: SyncDataType) {
        this._syncDataType = dataType;
    }
    public get syncDataType(): SyncDataType {
        if(this._syncDataType != undefined)
            return this._syncDataType;
        return SyncDataType.json;
    }
    private _session?: string;
    public set session(session: string) {
        this._session = session;
    }
    public get session(): string {
        if(this._session != undefined)
            return this._session;
        return '';
    }
    /** HTTP URL for getting webscoket URL  */
    private _URLForHostURL?: string;
    public set URLForHostURL(url: string) {
        this._URLForHostURL = url
    }
    public get URLForHostURL(): string {
        if(this,this._URLForHostURL != undefined)
            return this._URLForHostURL;
        return '';
    }
    /** HTTP URL for getting token */
    private _URLForToken?: string;
    public set URLForToken(url: string) {
        this._URLForToken = url;
    }
    public get URLForToken(): string {
        if(this._URLForToken != undefined)
            return this._URLForToken;
        return '';
    }
    /** 玩家登陆 token */
    private _token?: string;
    public set token(token: string) {
        this._token = token;
    }
    public get token(): string {
        if(this._token != undefined)
            return this._token;
        return UNDEFENEDSTRING;
    }
    /** host服务器的URL */
    private _hostURL?: string;
    public set hostURL(hostURL: string) {
        this._hostURL = hostURL;
    }
    public get hostURL() {
        if(this._hostURL != undefined)
            return this._hostURL;
        return UNDEFENEDSTRING;
    }
    /** 逻辑帧的运行帧率 */
    private _logicFPS?: number;
    public set logicFPS(logicFPS: number) {
        this._logicFPS = 1 / logicFPS;
    }
    public get logicFPS(): number {
        if(this._logicFPS != undefined)
            return this._logicFPS;
        return UNDEFENEDNUMBER;
    }
    /** 房间可容纳总玩家数 */
    private _roomPeopleNum?: number;
    public set roomPeopleNum(roomPeopleNum: number) {
        this._roomPeopleNum = roomPeopleNum;
    }
    public get roomPeopleNum(): number {
        if(this._roomPeopleNum != undefined)
            return this._roomPeopleNum;
        return UNDEFENEDNUMBER;
    }
    /** 本机玩家ID */
    private _localPlayerId?: number;
    public set localPlayerId(id: number) {
        this._localPlayerId = id;
    }
    public get localPlayerId(): number {
        if(this._localPlayerId != undefined)
            return this._localPlayerId;
        return UNDEFENEDNUMBER;
    }
    /** 本机玩家所在房间的ID */
    private _roomId?: string;
    public set roomId(roomId: string) {
        this._roomId = roomId;
    }
    public get roomId(): string {
        if(this._roomId != undefined)
            return this._roomId;
        return UNDEFENEDSTRING;
    }
    /** websocket 实例 */
    private _websocket?: WebSocket;
    public set websocket(websocket: WebSocket | undefined) {
        this._websocket = websocket;
    }
    public get websocket(): WebSocket | undefined{
        if(this._websocket != undefined)
            return this._websocket!;
        return undefined;
    }
    /** 心跳阀值，超过该阀值，触发心跳超时 */
    private _heartBeatThreholdValue?: number;
    public set heartBeatThreholdValue(value: number) {
        this._heartBeatThreholdValue = value;
    }
    public get heartBeatThreholdValue(): number {
        if(this._heartBeatThreholdValue != undefined)
            return this._heartBeatThreholdValue;
        return HEARTBEATTHREHOLDVALUESTARDARD;
    }
    /** 心跳时间计时器 */
    private heartBeatTimer: number = HEARTBEATTIMERDEFAULTVALUE;
    /** 是否运行进行心跳 */
    private _allowHeartBeat?: boolean;
    public set allowHeartBeat(flag: boolean) {
        this._allowHeartBeat = flag;
    }
    public get allowHeartBeat(): boolean {
        if(this._allowHeartBeat != undefined)
            return this._allowHeartBeat;
        return false;
    }
    /** 当前逻辑帧序号 */
    private _frameSyncSequenceNumber?: number;
    public set frameSyncSequenceNumber(sequenceNumber: number) {
        this._frameSyncSequenceNumber = sequenceNumber;
    }
    public get frameSyncSequenceNumber(): number {
        if(this._frameSyncSequenceNumber != undefined)
            return this._frameSyncSequenceNumber;
        return UNDEFENEDNUMBER;
    }
    /** 是否可以同步操作指令 */
    private _allowSyncUserCommands?: boolean;
    public set allowSyncUserCommands(flag: boolean) {
        this._allowSyncUserCommands = flag;
    }
    public get allowSyncUserCommands(): boolean {
        if(this._allowSyncUserCommands != undefined)
            return this._allowSyncUserCommands;
        return false;
    }
    /** RTT 单位ms */
    private _netRTT?: number;
    public set netRTT(RTT: number) {
        this._netRTT = RTT;
    }
    public get netRTT(): number {
        if(this._netRTT != undefined)
            return this._netRTT;
        return RTTDEFAULTVALUE;
    }
    /** rtt阀值倍率 */
    private _rttThreholdTimes?: number;
    public set rttThreholdTimes(times: number) {
        this._rttThreholdTimes = times;
    }
    public get rttThreholdTimes(): number {
        if(this._rttThreholdTimes != undefined)
            return this._rttThreholdTimes;
        return RTTDEFAULTTHREHOLDTIMES;
    }
    /**
     * 重置所有需要复原的成员变量
     */
    public resetAllMemberValues(): void {
        this.hostURL = UNDEFENEDSTRING;
        this.logicFPS = UNDEFENEDNUMBER;
        this.roomPeopleNum = UNDEFENEDNUMBER;
        this.localPlayerId = UNDEFENEDNUMBER;
        this.roomId = UNDEFENEDSTRING;
        this.onlineUsrList = undefined;
        this.offlineUsrList = undefined;
        this.token = UNDEFENEDSTRING;
        this.websocket = undefined;
        this.recvMsgQueue = undefined;
        this.heartBeatThreholdValue = HEARTBEATTHREHOLDVALUESTARDARD;
        this.heartBeatTimer = HEARTBEATTIMERDEFAULTVALUE;
        this.frameSyncSequenceNumber = UNDEFENEDNUMBER;
        this.allowSyncUserCommands = false;
        this.netRTT = RTTDEFAULTVALUE;
        this.rttThreholdTimes = RTTDEFAULTTHREHOLDTIMES;
        this.allowHeartBeat = false;
        this.userStatus = new UserStatus;
    }

    //#region 类内调用
    /** 用户绑定的HTTP GET Error回调函数 */
    private netErrorCallback?: Function;
    /** 用户绑定的登陆结果回调函数 */
    private joinRoomCallback?: Function;
    /** 用户绑定的重连获取房间信息回调函数 */
    private rejoinRoomCallback?: Function;
    /** 用户绑定的匹配结果注册回调函数 */
    private matchGroupCallback?: Function;  
    /** 用户绑定的开始帧同步回调函数 */
    private startFrameSyncCallback?: Function;
    /** 用户绑定的推送房间历史回调函数 */
    private requestHistoryFramesCallback?: Function;  
    /** 用户绑定的其他玩家恢复游戏回调函数 */
    private offlinePlayerResumeCallback?: Function;  
    /** 用户绑定的其他玩家掉线回调函数 */
    private remotePlayerOfflineCallback?: Function;  
    /** 用户绑定的游戏继续回调函数 */
    private resumeFrameSyncCallback?: Function;
    /** 用户绑定的服务器推送逻辑帧回调函数 */
    private frameCallback?: Function; 
    /** 用户绑定的服务器推送了异常的逻辑帧回调函数 */
    private recvUnknowFrameCallback?: Function; 

    /** 每一个帧同步帧间用户的操作列表 */
    private usrCommandsPerFrameSync?: number[];
    /** 消息接收队列 */
    private recvMsgQueue?: string[];
    /** 用户离线列表 */
    private offlineUsrList?: number[];
    /** 用户在线列表 */
    private onlineUsrList?: number[];

    /**
     * 要同步的指令
     * @param command 指令
     */
    public syncCommand(command: number) {
        if(this.usrCommandsPerFrameSync == undefined) { this.usrCommandsPerFrameSync = new Array<number>()}
        if (this.allowSyncUserCommands && this.usrCommandsPerFrameSync) {
            this.usrCommandsPerFrameSync.push(command);
        }
    }
    /**  
     * 获取同步操作指令的数组长度
     */
    public usrCommandsPerFrameSyncLength(): number {
        if(this.usrCommandsPerFrameSync != undefined)
            return this.usrCommandsPerFrameSync.length;
        return UNDEFENEDNUMBER;
    }
    /**
     * 获取指定index的操作指令
     */
    public getIndexedCommand(index: number): number {
        if(this.usrCommandsPerFrameSync != undefined){
            if(this.usrCommandsPerFrameSync[index]){
                return this.usrCommandsPerFrameSync[index];
            }
            return UNDEFENEDNUMBER;       
        }
        return UNDEFENEDNUMBER;
 
    }
    /**
     * 置空
     */
    public emptySyncCommandsPerFrameSync() {
        if(this.usrCommandsPerFrameSync != undefined)
            this.usrCommandsPerFrameSync = [];
    }
    /**
     * 尝试创建websocket连接
     */
    private tryToCreateWebsocket(): void {
        if (NetSyestem.getInstance().userStatus.wsURLState == WsURLState.ownWBURL
            && NetSyestem.getInstance().userStatus.tokenState == TokenState.ownToken) {
            this.createWebsocket();
        }
    }
    /** 创建websocket */
    private createWebsocket(): void {
        let token = NetSyestem.getInstance().token;
        this.websocket = new WebSocket(this.hostURL);
        log("[NetSyestem]create websocket with url :" + this.hostURL);
        // 建立连接成功
        this.websocket.onopen = function (event) {
            log("[NetSystem]websocket on open");
            NetSyestem.getInstance().sendMsg(Protocol.loginRoomSvr(token));
        }
        // 处理消息接收
        this.websocket.onmessage = function (event) {
            NetSyestem.getInstance().addMsg(event.data);
        }
        // 处理连接错误
        this.websocket.onerror = function (event) {
            error("[NetSyestem]websocket on error :" + event.eventPhase);
            NetSyestem.getInstance().dispatchNetError(NetErrorType.websocketConnectError);
        }
        // 处理连接关闭
        this.websocket.onclose = function (event) {
            warn("[NetSyestem]websocket on close" + event.reason);
            NetSyestem.getInstance().dispatchNetError(NetErrorType.webscoketConnectClosed);
        }
    }
    /**
     * 心跳超时
     */
    private heartBeatTimeout(): void {
        warn("HeartBeat time out !");
        this.resetAllMemberValues();
        // 心跳超时回调通知用户
        NetSyestem.getInstance().dispatchNetError(NetErrorType.heartBeatTimeout);
    }
    /**
     * 断开连接
     */
    private closeConnect(): void {
        if (this.websocket == undefined) {
            warn("websocket undefined.");
            return;
        }
        this.websocket.close();
        this.resetAllMemberValues();
    }

    //#endregion

    //#region SDK内调用
    /** 自动登陆 */
    private _autoLogin?: boolean;
    public set autoLogin(autoLogin: boolean) {
        this._autoLogin = autoLogin;
    }
    public get autoLogin(): boolean {
        if(this._autoLogin)
            return this._autoLogin;
        return false;
    }

    public getHttpServerURL(ip: string, httpPort: number): void {
        let url = "http://" + ip + ":" + httpPort.toString() + "/www/getServer";
        this.URLForHostURL = url;
    }

    public getTokenServerURL(ip: string, httpPort: number, uid: number): void {
        let url = "http://" + ip + ":" + httpPort.toString() + "/www/createJwtToken?id=" + uid.toString();
        this.localPlayerId = uid;
        this.URLForToken = url;
    }
    /**
    * 以Get方式发送HTTP请求，从HTTP服务器获取host server的URL 
    * @param httpURL HTTP服务器的URL
    */
    public getHostURL(): void {
        var request = new XMLHttpRequest();
        request.onreadystatechange = function () {
            if (request.readyState == XMLHttpRequestReadyState.DONE && request.status == XMLHTTPREQUESTSUCCESS) {
                let json = JSON.parse(request.responseText);
                NetSyestem.getInstance().hostURL = "ws://" + json["outIp"] + ":" + json["wsPort"] + json["wsUri"];
                NetSyestem.getInstance().roomPeopleNum = json["roomPeople"];
                NetSyestem.getInstance().logicFPS = json["fps"];
                NetSyestem.getInstance().userStatus.wsURLState = WsURLState.ownWBURL;
                NetSyestem.getInstance().tryToCreateWebsocket();
                log("[NetSyestem]success get websocket url :" + NetSyestem.getInstance().hostURL,
                    "FPS: ", NetSyestem.getInstance().logicFPS,
                    "roomPeopleNum:", NetSyestem.getInstance().roomPeopleNum);
            }
        }
        request.onerror = function () {
            error("HTTP GET Error, HTTP server not responsed ! error status:", this.status);
            NetSyestem.getInstance().dispatchNetError(NetErrorType.getWebsocketURLFailed);
        }
        request.open("GET", NetSyestem.getInstance().URLForHostURL, true);
        log("[NetSyestem]send http req to :" + NetSyestem.getInstance().URLForHostURL);
        request.send();
    }
    /**
    * 发送uid到http server 获取token
    * @param tokenURL 获取token 的HTTP URL
    */
    public getToken(): void {
        // // 测试 临时使用 localstorage
        // let localToken = sys.localStorage.getItem("Token");
        // if (localToken != -1 && localToken != 0 && localToken != null && localToken != undefined) {
        //     NetSyestem.getInstance().token = localToken;
        //     NetSyestem.getInstance().userStatus.tokenState = TokenState.ownToken;
        //     this.tryToCreateWebsocket();
        //     return;
        // }

        let request = new XMLHttpRequest();
        request.onreadystatechange = function () {
            if (request.readyState == XMLHttpRequestReadyState.DONE && request.status == XMLHTTPREQUESTSUCCESS) {
                let json = JSON.parse(request.responseText);
                NetSyestem.getInstance().localPlayerId = json["Uid"];
                NetSyestem.getInstance().token = json["Token"];
                NetSyestem.getInstance().userStatus.tokenState = TokenState.ownToken;
                NetSyestem.getInstance().tryToCreateWebsocket();
                log("[NetSyestem]success get token :" + NetSyestem.getInstance().token);

                // 测试 临时存入token
                //sys.localStorage.setItem("Token", NetSyestem.getInstance().token);
            }
        }
        request.onerror = function () {
            error("GET Token Error! error status:", this.status);
            NetSyestem.getInstance().dispatchNetError(NetErrorType.getTokenFailed);
        }
        request.open("GET", NetSyestem.getInstance().URLForToken, true);
        log("[NetSyestem]send uid to " + NetSyestem.getInstance().URLForToken);
        request.send();
    }
    /** 发送登陆申请 */
    public sendLoginReq(): void {
        NetSyestem.getInstance().getHostURL();
        NetSyestem.getInstance().getToken();
    }
    /** 发送重连申请 */
    public sendRejoinRoomReq(): void {
        log("[NetSyestem]rejoin to room :", NetSyestem.getInstance().roomId);
        NetSyestem.getInstance().userStatus.reconnectState = ReconnectState.readyFor;
        NetSyestem.getInstance().sendMsg(Protocol.getMyRoom(NetSyestem.getInstance().localPlayerId, NetSyestem.getInstance().roomId));
    }
    /** 发送匹配申请 */
    public sendMatchReq(): void {
        log("[NetSyestem]match sign for ", NetSyestem.getInstance().localPlayerId);
        NetSyestem.getInstance().sendMsg(Protocol.MatchGroup(NetSyestem.getInstance().localPlayerId));
    }
    /** 取消匹配 */
    private sendCancelMatchReq(): void {
        // 发送玩家取消匹配消息
        log("[NetSyestem]match sign cancel for ", NetSyestem.getInstance().localPlayerId);
        NetSyestem.getInstance().sendMsg(Protocol.cancelMatch(NetSyestem.getInstance().localPlayerId));
    }

    /** 派发 Net Error */
    public dispatchNetError(data: NetErrorType): void {
        if (this.netErrorCallback != undefined) {
            this.netErrorCallback.call(this, data);
        }
    }
    /** 派发loginRes给注册对象 */
    public dispatchJoinRoom(data: InitRoom): void {
        if (this.joinRoomCallback != undefined) {
            this.joinRoomCallback.call(this, data);
        }
    }
    /** 派发需要重连事件 */
    public disptachRejoinRoom(data: RoomInfo): void {
        if (this.rejoinRoomCallback != undefined) {
            this.rejoinRoomCallback.call(this, data);
        }
    }
    /** 派发匹配事件 */
    public dispatchMatchGroup(data: MatchGroup): void {
        if (this.matchGroupCallback != undefined) {
            this.matchGroupCallback.call(this, data);
        }
    }
    /** 派发开始帧同步事件 */
    public dispatchStartFrameSync(data: StartFrameSync): void {
        if(this.startFrameSyncCallback != undefined) {
            this.startFrameSyncCallback.call(this, data);
        }
    }
    /** 派发服务器推送历史房间信息事件 */
    public dispatchRoomHistoryFrames(data: RoomHistroyFrames): void {
        if (this.requestHistoryFramesCallback != undefined) {
            this.requestHistoryFramesCallback.call(this, data);
        }
    }
    /** 派发有玩家恢复游戏事件 */
    public dispatchOfflinePlayerResume(data: OfflinePlayerResume): void {
        if (this.offlinePlayerResumeCallback != undefined) {
            this.offlinePlayerResumeCallback.call(this, data);
        }
    }
    /** 派发其他玩家掉线事件 */
    public dispatchRemotePlayerOffline(data: RemotePlayerOffline): void {
        if (this.remotePlayerOfflineCallback != undefined) {
            this.remotePlayerOfflineCallback.call(this, data);
        }
    }
    /** 派发游戏继续事件 */
    public dispatchResumeFrameSync(): void {
        if (this.resumeFrameSyncCallback != undefined) {
            this.resumeFrameSyncCallback.call(this);
        }
    }
    /** 派发服务器同步操作事件 */
    public dispatchFrame(data: Operation): void {
        if (this.frameCallback != undefined) {
            this.frameCallback.call(this, data);
        }
    }
    /** 派发服务器同步过来帧号对不上的逻辑帧 */
    public dispatchRecvUnknowFrame(data: RecvFrame): void {
        if (this.recvUnknowFrameCallback != undefined) {
            this.recvUnknowFrameCallback.call(this, data);
        }
    }
    /**
     * 请求房间全部历史操作
     */
    public requestRoomHistory(): void {
        if (NetSyestem.getInstance().userStatus.reconnectState == ReconnectState.readyFor) {
            log("[Game]request room history | send player id : " + NetSyestem.getInstance().localPlayerId + " room id : " + NetSyestem.getInstance().roomId);
            NetSyestem.getInstance().sendMsg(Protocol.requestRoomHistoryFrames(NetSyestem.getInstance().localPlayerId, NetSyestem.getInstance().roomId, 0, -1));
        }
    }
    /**
     * RTT test
     * @param serverPongMsg
     */
    public testRTT(serverPongMsg: ServerPong): void {
        if (serverPongMsg.clientReceiveTime - serverPongMsg.addTime < this.rttThreholdTimes * NetSyestem.getInstance().netRTT) {
            NetSyestem.getInstance().netRTT = serverPongMsg.clientReceiveTime - serverPongMsg.addTime;
            //log("[NetSyestem] current RTT :", NetSyestem.getInstance().RTT);
            setTimeout(() => {
                NetSyestem.getInstance().sendMsg(Protocol.clientPing());
                //log("[NetSyestem] client send ping to test RTT !");
            }, this.rttThreholdTimes * NetSyestem.getInstance().netRTT);
        }
        else {
            //log("[NetSyestem]excepted rtt : ", serverPongMsg.clientReceiveTime - serverPongMsg.addTime,
            //    "last normal RTT :", NetSyestem.getInstance().RTT);
            this.rttThreholdTimes += 1;
            if (serverPongMsg.clientReceiveTime - serverPongMsg.addTime < 1000) {
                setTimeout(() => {
                    NetSyestem.getInstance().sendMsg(Protocol.clientPing());
                    //log("[NetSyestem] client send ping to test RTT !");
                }, this.rttThreholdTimes * NetSyestem.getInstance().netRTT);
            }
            else {
                log("[NetSyestem] RTT over !");
                NetSyestem.getInstance().closeConnect();
                NetSyestem.getInstance().resetAllMemberValues();
                NetSyestem.getInstance().dispatchNetError(NetErrorType.RTTOver);
            }
        }
    }
    /**
     * 心跳,放在update中
     */
    public heartBeat(dt: number): void {
        if (this.allowHeartBeat) {
            this.heartBeatTimer += dt;
            if (this.heartBeatTimer > this.heartBeatThreholdValue) {
                this.heartBeatTimeout();
            }
        }
    }
    /**
     * 发送消息
     * @param content 消息内容
     * @returns 
     */
    public sendMsg(content: string): void {
        if (this.websocket == undefined) {console.log("4"); return; }
        this.websocket.send(content);
    }
    /**
     * 添加消息到消息待处理队列
     * @param msg 
     */
    public addMsg(msg: string) {
        if (this.recvMsgQueue != undefined)
            this.recvMsgQueue.push(msg);
        else {
            this.recvMsgQueue = new Array<string>();
            this.recvMsgQueue.push(msg);
        }
    }
    /**
     * 获取消息队列中的第一条消息
     * @returns 
     */
    public getMsg(): string {
        if (this.recvMsgQueue == undefined) { return ''; }
        if (this.recvMsgQueue.length <= 0) { return ''; }
        return this.recvMsgQueue.shift() as string;;
    }
    /** 消息等待处理 */
    public msgWaitingProcess(): boolean {
        if (this.recvMsgQueue == undefined) { return false; }
        if (this.recvMsgQueue.length <= 0) { return false; }
        return true;
    }
    /** 重置心跳计时器的时间 */
    public resetHeartBeatTimer(): void {
        this.heartBeatTimer = 0;
    }
    /** 添加离线人员列表成员 */
    public addOfflineUserList(playerId: number): void {
        if(this.offlineUsrList == undefined) { this.offlineUsrList = new Array<number>(); }
        if (this.offlineUsrList.indexOf(playerId) == -1) {
            this.offlineUsrList.push(playerId);
        }
    }
    /**
     * 查询该玩家ID是否在掉线列表成员中，如果在则返回ID并从在线列表中移除
     * @param playerId 
     * @returns -1:表示不存在该ID
     */
    public queryOfflineUserList(playerId: number): number {
        if (this.offlineUsrList == undefined) { return UNDEFENEDNUMBER; }
        let index = this.offlineUsrList.findIndex(value => value == playerId)
        if (index == undefined) {
            return UNDEFENEDNUMBER;
        } else {
            let offlineId = this.offlineUsrList[index];
            this.offlineUsrList.splice(index, 1);
            return offlineId;
        }
    }
    /**
     * 掉线玩家列表是否为空，为空则表示当前没有玩家掉线
     */
    public offlineUserListIsEmpty(): boolean {
        if (this.offlineUsrList != undefined) {
            if (this.offlineUsrList.length == 0)
                return true;
            else
                return false;
        } else {
            this.offlineUsrList = new Array<number>();
            return true;
        }
    }
    /**
     * 获取玩家列表中玩家的总数
     * @returns 玩家总数
     */
    public getOnlineUserNum(): number {
        if(this.onlineUsrList != undefined)
            return this.onlineUsrList.length;
        return UNDEFENEDNUMBER;
    }
    /**
     * 获取指定index的玩家uid
     * @param index 玩家uid
     * @returns 
     */
    public getIndexedUserId(index: number): number {
        if (this.onlineUsrList == undefined || this.onlineUsrList[index] == undefined) { return UNDEFENEDNUMBER; }
        return this.onlineUsrList[index];
    }
    /**
     * 添加玩家进玩家列表
     * @param playerId 玩家ID
     */
    public addOnlineUserList(playerId: number): void {
        if (this.onlineUsrList == undefined) { this.onlineUsrList = new Array<number>(); }
        if (this.onlineUsrList.indexOf(playerId) == -1) {
            this.onlineUsrList.push(playerId);
            log("num1", playerId);
        }
    }
    /**
     * 查询该玩家ID是否在在线列表成员中，如果在则返回ID
     * @param playerId 
     */
    public queryOnlineUserList(playerId: number): number {
        if (this.onlineUsrList == undefined) { return UNDEFENEDNUMBER; }
        let index = this.onlineUsrList.find(index => { index == playerId }) as number;
        if (index != -1) {
            return index;
        }
        log("[NetSyestem] player " + playerId + "not exist in userOnline list");
        return UNDEFENEDNUMBER;
    }
    ////#endregion

    //#region User调用
    /**
     * 用户状态机
     * @description 记录了各类用户状态
     */
    private _userStatus?: UserStatus;   
    public get userStatus() : UserStatus {
        if(this._userStatus != undefined)
            return this._userStatus; 
        else{
            this._userStatus = new UserStatus;
            return this._userStatus;
        }
    }
    public set userStatus(v: UserStatus) {
        this._userStatus = v;
    }
    
    /**
     * 登陆接口
     * @description 登陆websocket服务器
     * @attention autoLogin模式下不可用！
     */
    public joinRoom(): void {
        if (NetSyestem.getInstance().userStatus.wsURLState == WsURLState.notYet
            && NetSyestem.getInstance().userStatus.tokenState == TokenState.noToken
            && !this.autoLogin) {
            NetSyestem.getInstance().sendLoginReq();
        }
    }
    /**
    * 重连接口
    * @description 发起重连申请
    */
    public rejoinRoom(): void {
        if (NetSyestem.getInstance().userStatus.reconnectState == ReconnectState.can
            && !this.autoLogin) {
            this.sendRejoinRoomReq();
        }
    }
    /**
     * 匹配接口
     * @description 发起匹配申请
     */
    public matchGroup(): void {
        // 只有当 登陆状态为已登陆，匹配状态为 未匹配时，才能发送匹配申请
        if (NetSyestem.getInstance().userStatus.loginState == LoginState.aleadyLogin
            && NetSyestem.getInstance().userStatus.mtachState == MatchState.notMatch
            && !this.autoLogin) {
            this.sendMatchReq();
        }
    }
    /**
     * 取消匹配接口
     */
    public cancelMatch(): void {
        // 只有当 登陆状态为 已经登陆，匹配状态为 已经匹配时，才能发送匹配申请
        if (NetSyestem.getInstance().userStatus.loginState == LoginState.aleadyLogin
            && NetSyestem.getInstance().userStatus.mtachState == MatchState.alreadyMatch
            && !this.autoLogin) {
            this.sendCancelMatchReq();
        }
    }
    /**
     * 初始化完毕接口
     * @description 玩家初始化资源完毕后，向服务器发送本地资源初始化准备完毕消息
     */
    public readyFrameSync(): void {
        log("[Group]player ready！|", "playerId :" + NetSyestem.getInstance().localPlayerId, "roomId : " + NetSyestem.getInstance().roomId);
        NetSyestem.getInstance().sendMsg(Protocol.playerReady(NetSyestem.getInstance().localPlayerId, NetSyestem.getInstance().roomId));
    }
    /**
     * 恢复全部历史操作
     * @description 当玩家执行完全部历史操作后，发送恢复完成
     */
    public historyFramesFinished(): void {
        NetSyestem.getInstance().sendMsg(Protocol.playerResumeGame(NetSyestem.getInstance().roomId, NetSyestem.getInstance().localPlayerId, NetSyestem.getInstance().frameSyncSequenceNumber));
        NetSyestem.getInstance().sendMsg(Protocol.getMyRoom(NetSyestem.getInstance().localPlayerId, NetSyestem.getInstance().roomId));
        NetSyestem.getInstance().allowHeartBeat = true;
        log("[Game]恢复操作完成!");
    }
    /**
     * 绑定 Net error 回调接口
     * @param callback 用户自定义回调函数
     * @description net error 后，用户获得该错误通知
     * @example
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: string):void {
     *  // netError
     * } 
     * // 绑定自定义callback
     * NetSyestem.onNetError(userCustomCallback.bind(this));
     * ```
     */
    public onNetError(callback: Function): void {
        this.netErrorCallback = callback;
    }
    /**
     * 绑定 加入房间成功 回调接口
     * @param callback 用户自定义回调函数
     * @description 加入房间成功后，用户可以获取房间信息
     * @example
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: InitRoom):void{
     *     // 根据data类型做具体操作
     * } 
     * // 绑定自定义callback
     * NetSyestem.onJoinRoom(userCustomCallback.bind(this));
     * ```
     */
    public onJoinRoom(callback: Function): void {
        this.joinRoomCallback = callback;
    }
    /**
     * 绑定 重连申请结果 回调函数接口
     * @param callback 用户自定义回调函数
     * @description 重连后会收到服务器推送的历史房间信息 roomInfo
     * @example
     * // 用户自定义callback
     * userCutsomCallback(data: RoomInfo):void {
     * // dosomething ...
     * } 
     * // 绑定自定义callback
     * NetSyestem.onRejoinRoom(userCustomCallback.bind(this));
     */
    public onRejoinRoom(callback: Function): void {
        this.rejoinRoomCallback = callback;
    }
    /**
     * 绑定 匹配结果 回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 完成匹配后
     * @example
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: MatchGroup):void {
     * // dosomething ...
     * } 
     * // 绑定自定义callback
     * NetSyestem.onMatchGroup(userCustomCallback.bind(this));
     * ```
     */
    public onMatchGroup(callback: Function): void {
        this.matchGroupCallback = callback;
    }
    /**
     * 绑定 开始帧同步 回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 开始帧同步
     * @example
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: StartFrameSync):void{
     *  // dosomething ...
     * } 
     * // 绑定自定义callback
     * NetSyestem.onStartFrameSync(userCustomCallback.bind(this));
     * ```
     */
    public onStartFrameSync(callback: Function): void {
        this.startFrameSyncCallback = callback;
    }
    /**
     * 绑定 服务器推送房间历史 回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 完成接收全部房间历史操作后，用户通过该回调可以获得全部房间历史操作
     * @example 
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: RoomHistroyFrames):void{
     *  // 根据data类型做具体操作
     * } 
     *  // 绑定自定义callback
     * NetSyestem.onHistoryFrames(userCustomCallback.bind(this));
     * ```
     */
    public onHistoryFrames(callback: Function): void {
        this.requestHistoryFramesCallback = callback;
    }
    /**
     * 绑定 有其他玩家恢复游戏 回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当有玩家恢复游戏时，通过该接口绑定的回调函数将会响应，用户可以通过该回调函数获取信息
     * @example 
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: OfflinePlayerResume):void{
     *  // 根据data类型做具体操作
     * } 
     *  // 绑定自定义callback
     * NetSyestem.onOfflinePlayerResume(userCustomCallback.bind(this));
     * ```
     */
    public onOfflinePlayerResume(callback: Function): void {
        this.offlinePlayerResumeCallback = callback;
    }
    /**
     * 绑定 有其他玩家掉线 回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当有玩家掉线的时候，通过该接口绑定的回调函数将会响应，用户可以通过该回调函数获取信息
     * @example
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback(data: RemotePlayerOffline): void {
     *  // 根据data类型做具体操作
     * } 
     *  // 绑定自定义callback
     * NetSyestem.onRemotePlayerOffline(userCustomCallback.bind(this));
     * ```
     */
    public onRemotePlayerOffline(callback: Function): void {
        this.remotePlayerOfflineCallback = callback;
    }
    /**
     * 绑定 游戏继续 回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当游戏继续的时候，通过该接口绑定的回调函数将会响应，用户可以通过该回调函数得知消息
     * ```typescript
     * // 用户自定义callback
     * userCutsomCallback():void {
     *  // 具体操作
     * } 
     *  // 绑定自定义callback
     * NetSyestem.onFrameSyncResume(userCustomCallback.bind(this));
     * ```
     */
    public onResumeFrameSync(callback: Function): void {
        this.resumeFrameSyncCallback = callback;
    }
    /**
     * 绑定 服务器推送逻辑帧 回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当服务器每次同步过来逻辑帧时，通过该接口绑定的回调函数将会响应，用户可以通过该回调函数得知收到的玩家的操作
     * ```typescript
     * // 用户自定义callback
     * userCustomCallback(data: Operation): void {
     *  // 具体操作
     * }
     *  // 绑定自定义callback
     * NetSyestem.onRecvFrame(userCustomCallback.bind(this));
     * ```
     */
    public onRecvFrame(callback: Function): void {
        this.frameCallback = callback;
    }
    /**
     * 绑定 服务器推送了异常帧号的逻辑帧 回调函数接口
     * @param callback 用户自定义的回调函数
     * @description 当服务器同步逻辑帧时，收到了异常帧号的逻辑帧数据，用户可以通过该回调函数得知该异常数据具体内容
     * ```typescript
     * // 用户自定义callback
     * userCustomCallback(data: RecvFrame): void {
     *  // 具体操作
     * }
     *  // 绑定自定义callback
     * NetSyestem.onRecvUnknowFrame(userCustomCallback.bind(this));
     * ```
     */
    public onRecvUnknowFrame(callback: Function): void {
        this.recvUnknowFrameCallback = callback;
    }
    //#endregion 

}