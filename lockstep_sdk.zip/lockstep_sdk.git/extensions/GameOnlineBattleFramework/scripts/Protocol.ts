import { log } from 'cc';
import { NetSyestem } from './NetSystem';
/** 网络错误类型 */
export enum NetErrorType {
    getWebsocketURLFailed = 1,
    getTokenFailed = 2,
    webscoketConnectClosed = 3,
    websocketConnectError = 4,
    joinRoomFailed = 5,
    matchSignFailed = 6,
    heartBeatTimeout = 7,
    RTTOver = 8,
}
/** token状态 */
export enum TokenState {
    /** 当前没有获得token */
    noToken = 0,
    /** 已经拥有token */
    ownToken = 1,
}
/** webscoket URL 状态 */
export enum WsURLState {
    /** 没有获得webscoket url  */
    notYet = 0,
    /** 已经获取websocket url */
    ownWBURL = 1,
}
/** 登陆状态 */
export enum LoginState {
    /** 没有登陆 */
    notLogin = 0,
    /** 已经登陆 */
    aleadyLogin = 1,
}
/** 重连状态 */
export enum ReconnectState {
    /** 不允许重连 */
    not = 0,
    /** 允许重连 */
    can = 1,
    /** 正在准备重连 */
    readyFor = 2,
    /** 正在恢复中 */
    recovering = 3,
    /** 恢复重连完成 */
    recovered = 4,
}
/** 匹配状态 */
export enum MatchState {
    notMatch = 0,
    alreadyMatch = 1,
}
/**
 * 用户状态机
 */
export class UserStatus {
    public tokenState: TokenState = TokenState.noToken;
    public wsURLState: WsURLState = WsURLState.notYet;
    public loginState: LoginState = LoginState.notLogin;
    public reconnectState: ReconnectState = ReconnectState.not;
    public mtachState: MatchState = MatchState.notMatch;
}
/** 同步模式 */
export enum SyncMode {
    lockstep = 1,
    bucket = 2,
}
/** 传输协议格式 */
export enum SyncDataType {
    json = 1,
    protobuf = 2,
}
/**
 * 传输协议体
 */
export class Protocol {
    /**
     * 把协议ID与协议内容粘合成一条消息
     * @param msgH 消息头
     * @param id 协议ID
     * @param content 协议内容:JSON Str
     * @returns 
     */
    public static makeMsg(id: number, content: string): string {
        let syncMode = NetSyestem.getInstance().syncMode.toString();
        let syncDataType = NetSyestem.getInstance().syncDataType.toString();
        let session = NetSyestem.getInstance().session.toString();
        let msg = syncMode + syncDataType + id.toString() + session + content;
        return msg;
    }
    /*------------------以下对应发送给后端的apilist------------------ */
    //#region 客户端发往服务端的协议格式
    /**
     * 登陆房间分配服务器
     * @protocol 1000 / login
     * @param token 玩家token
     */
    public static loginRoomSvr(token: string): string {
        let obj = {
            token
        };
        obj.token = token;
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1000, jsonStr);
    }
    /**
     * 1002 客户端回应服务器的RTT请求
     * @param addTime 直接复制S端 - 1003消息 - addTime
     * @param serverResponseTime 直接复制S端发过来的1003消息里对应的serverResponseTime
     * @returns 
     */
    public static clientPong(addTime: number, serverResponseTime: number, rttTimeout: number, rttTimes: number): string {
        let obj = {
            addTime,
            clientReceiveTime: -1,
            serverResponseTime,
            rttTimeout,
            rttTimes
        }
        obj.addTime = addTime;
        obj.clientReceiveTime = new Date().getTime();
        obj.serverResponseTime = serverResponseTime;
        obj.rttTimeout = rttTimeout;
        obj.rttTimes = rttTimes;
        let data = JSON.stringify(obj);
        return this.makeMsg(1002, data);
    }
    /**
     * 1004 客户端主动发送RTT测试
     * @returns 
     */
    public static clientPing(): string {
        let obj = {
            addTime: -1,
            clientReceiveTime: -1,
            serverResponseTime: -1,
            rttTimeout: -1,
            rttTimes: -1
        }
        obj.addTime = new Date().getTime();
        let data = JSON.stringify(obj);
        return this.makeMsg(1004, data);
    }
    /**
     * 1006 客户端发送心跳包？？？
     * @returns 
     */
    public static clientHeartbeat(): string {
        let obj = {
            time: -1
        };
        obj.time = Math.round((new Date().getTime() / 1000));
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1006, jsonStr);
    }
    /**
     * 1008 掉线恢复游戏
     * @param roomId 房间编号
     * @param playerId 玩家ID
     * @param sequenceNumber 逻辑帧序号
     * @returns 封装好的消息字符串包
     */
    public static playerResumeGame(roomId: string, playerId: number, sequenceNumber: number): string {
        let obj = {
            roomId,
            playerId,
            sequenceNumber
        };
        obj.roomId = roomId;
        obj.playerId = playerId;
        obj.sequenceNumber = sequenceNumber;
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1008, jsonStr);
    }
    /**
    * 1012的Operations数组里的单个元素
    * @param playerId 玩家ID
    * @param event 玩家操作类型 ，无操作默认 empty
    * @param value 玩家操作指令号 ， 无操作默认 -1
    * @param id 玩家操作指令序号
    * @returns 
    */
    public static operation(playerId: number, event: string = 'empty', value: string = "-1", id: number = 0): object {
        let obj = {
            playerId,
            event,
            value,
            id
        }
        obj.playerId = playerId;
        obj.event = event;
        obj.value = value;
        obj.id = id;
        return obj;
    }
    /**
     * 1012 推送玩家操作指令 
     * @param roomId 房间ID
     * @param sequenceNumber 逻辑帧序列号
     * @param operations 玩家操作指令内容数组
     * @param id 操作指令序号
     * @returns 
     */
    public static playerOperations(roomId: string, sequenceNumber: number, operations: object[], id: number): string {
        let obj = {
            roomId,
            sequenceNumber,
            operations,
            id
        }
        obj.roomId = roomId;
        obj.sequenceNumber = sequenceNumber;
        obj.operations = operations;
        obj.id = id;
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1012, jsonStr);
    }
    /**
     * 1018 玩家报名/准备
     * @param playerId 玩家ID
     * @param roomId 房间ID
     * @returns 
     */
    public static playerReady(playerId: number, roomId: string): string {
        let obj = {
            playerId,
            roomId
        };
        obj.playerId = playerId;
        obj.roomId = roomId;
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1018, jsonStr);
    }
    /**
     * 1022 一局游戏结束
     * @param roomId 房间编号
     * @param sequenceNumber 逻辑帧编号
     * @param result 游戏结果
     * @returns 
     */
    public static gameOver(roomId: string, sequenceNumber: number, result: string): string {
        let obj = {
            roomId,
            sequenceNumber,
            result
        };
        obj.roomId = roomId;
        obj.sequenceNumber = sequenceNumber;
        obj.result = result;
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1022, jsonStr);
    }
    /**
     * 1024 玩家要恢复游戏,申请房间历史操作
     * @param playerId 玩家ID
     * @param roomId 房间ID
     * @param sequenceNumberStart 恢复逻辑的起始帧号
     * @param sequenceNumberEnd 恢复逻辑帧的最终帧号
     * @returns 
     */
    public static requestRoomHistoryFrames(playerId: number, roomId: string, sequenceNumberStart: number, sequenceNumberEnd: number): string {
        let obj = {
            playerId,
            roomId,
            sequenceNumberStart,
            sequenceNumberEnd
        };
        obj.playerId = playerId;
        obj.roomId = roomId;
        obj.sequenceNumberStart = sequenceNumberStart;
        obj.sequenceNumberEnd = sequenceNumberEnd;
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1024, jsonStr);
    }
    /**
     * 获取一个房间的信息
     * @protocol 1028 / getRoom
     * @param playerId 玩家ID
     * @param roomId 房间ID
     * @returns 
     */
    public static getMyRoom(playerId: number, roomId: string): string {
        let obj = {
            playerId,
            roomId
        };
        obj.playerId = playerId;
        obj.roomId = roomId;
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1028, jsonStr);
    }
    /**
     * 玩家匹配，由服务器分配组
     * @protocol 1030 / playerMatchSign
     * @param playerId 玩家ID
     * @returns
     */
    public static MatchGroup(playerId: number): string {
        let obj = {
            playerId
        };
        obj.playerId = playerId;
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1030, jsonStr);
    }
    /**
     * 玩家取消匹配报名
     * @protocol 1032 / playerMatchSignCancel
     * @param playerId 玩家ID
     * @returns 
     */
    public static cancelMatch(playerId: number): string {
        let obj = {
            playerId
        };
        obj.playerId = playerId;
        const jsonStr = JSON.stringify(obj);
        return this.makeMsg(1032, jsonStr);
    }
    //#endregion

    /**
     * 把单个player放进数组内
     * @param playerArray json中的playerList
     * @returns 
     */
    public static pushPlayerIntoArray(playerArray: Array<Player>): Player[] {
        let playerList: Player[] = [];
        if (playerArray == undefined || playerArray.length == 0) {
            playerList.push(new Player());
            console.warn("[Protocol]playerList equals null , unexpected player !");
        }
        for (let index = 0; index < playerArray.length; index++) {
            const element = playerArray[index];
            playerList.push(new Player(element["id"], element["status"], element["roomId"]));
        }
        return playerList;
    }
    /**
     * 把单个operation放进数组
     * @param operationArray 
     * @returns 
     */
    public static pushOperationIntoArray(operationArray: Array<Operation>): Operation[] {
        let operationList: Operation[] = [];
        if (operationArray == undefined || operationArray.length == 0) {
            operationList.push(new Operation());
            console.warn("[Protocol]operations equals null , unexpected operation !");
        }
        for (let index = 0; index < operationArray.length; index++) {
            const element = operationArray[index];
            operationList.push(new Operation(element["id"], element["event"], element["value"], element["playerId"]));
        }
        return operationList;
    }
    /**
     * 把单个roomHistroy放进数组
     * @param roomHistoryArray 
     * @returns 
     */
    public static pushRoomHistroyIntoArray(roomHistoryArray: Array<HistoryFrame>): HistoryFrame[] {
        let roomHistroyList: HistoryFrame[] = [];
        if (roomHistoryArray == undefined || roomHistoryArray.length == 0) {
            roomHistroyList.push(new HistoryFrame());
            console.warn("[Protocol]roomhistroy equals null , unexpected roomhistory !");
        }
        for (let index = 0; index < roomHistoryArray.length; index++) {
            const element = roomHistoryArray[index];
            roomHistroyList.push(new HistoryFrame(element["id"], element["action"], element["content"]));
        }
        // let roomHistroy = roomHistoryArray.map((item)=>item.)
        return roomHistoryArray;
    }
}

// ------- 解析S端发送过来的消息的 ----------
/**
 * 
 *@protocol 1001 / LoginRes 登陆结果 
 */
export class InitRoom {
    /** 协议编号 */
    public msgId: number = -1;
    /** 登陆状态码 */
    public code: number = -1;
    /** 错误消息信息 */
    public errMsg: string = "";
    /** 玩家信息 */
    public player: Player = new Player();
    /**
     * ctor 对收到的信息进行解析并存储
     * @param msg 收到的消息字符串
     */
    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.code = jsonObj["code"];
        this.errMsg = jsonObj["errMsg"];
        if (this.code == 200)
            this.player = new Player(jsonObj["player"]["id"], jsonObj["player"]["status"], jsonObj["player"]["roomId"]);
        else {
            this.player = new Player(0, 0, '');
        }
        log("[Protocol]InitRoom |",
            "msgId:" + this.msgId,
            "code:" + this.code,
            "errMsg:" + this.errMsg,
            "playerId:" + this.player.id,
            "status:" + this.player.status,
            "roomId:" + this.player.roomId);
    }
}
export class Player {
    /** 玩家ID */
    public id: number = -1;
    /** 玩家状态 */
    public status: number = -1;
    /** 玩家所在的房间ID */
    public roomId: string = "";

    constructor(id: number = -1, status: number = -1, roomId: string = "") {
        this.id = id;
        this.status = status;
        this.roomId = roomId;
    }
}
/**
 * 1003 S端测试RTT
 */
export class ServerPing {
    /** 协议序号 */
    public msgId: number = -1;
    /** S端发送消息的时间戳，C端收到原路复制 */
    public addTime: number = -1;
    /** 客户端填写，收到消息的时间 */
    public clientReceiveTime: number = -1;
    /** C端收到原路复制 */
    public serverResponseTime: number = -1;
    /** C端收到原路复制 */
    public rttTimeout: number = -1;
    /** C端收到原路复制 */
    public rttTimes: number = -1;

    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.addTime = jsonObj["addTime"];
        this.clientReceiveTime = new Date().getTime();
        this.serverResponseTime = jsonObj["serverResponseTime"];
        this.rttTimeout = jsonObj["rttTimeout"];
        this.rttTimes = jsonObj["rttTimes"];
    }
}
/**
 * 1005 S端响应C端测试RTT
 * C端可以根据clientReceiveTime - addTime 计算出一次RTT
 */
export class ServerPong {
    /** 协议序号 */
    public msgId: number = -1;
    /** C端收到原路复制 */
    public addTime: number = -1;
    /** C端填写，收到这条消息的时间戳 */
    public clientReceiveTime: number = -1;
    /** S端收到消息的时间，C端原路复制 */
    public serverResponseTime: number = -1;
    /** C端原路复制 */
    public rttTimeout: number = -1;
    /** C端原路复制 */
    public rttTimes: number = -1;

    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.addTime = jsonObj["addTime"];
        this.clientReceiveTime = new Date().getTime();
        this.serverResponseTime = jsonObj["serverResponseTime"];
        this.rttTimeout = jsonObj["rttTimeout"];
        this.rttTimes = jsonObj["rttTimes"];
    }
}
/**
 * 匹配组队
 * @protocol 1007 / EnterBattle
 */
export class MatchGroup {
    /** 协议序号 */
    public msgId: number = -1;
    /** 随机数种子 */
    public randSeek: number = -1;
    /** 房间ID */
    public roomId: string = "";
    /** 逻辑帧序号 */
    public sequenceNumber: number = -1;
    /** 房间状态 */
    public status: number = -1;
    /** 玩家列表，存放了每个玩家的信息 */
    public playerList: Player[] = [];
    /** 玩家列表中存的玩家个数 */
    public listNum: number = -1;
    /**
     * ctor 对收到的信息进行解析并存储
     * @param msg 收到的消息字符串
     */
    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.randSeek = jsonObj["randSeek"];
        this.roomId = jsonObj["roomId"];
        this.sequenceNumber = jsonObj["sequenceNumber"];
        this.status = jsonObj["status"];
        this.playerList = Protocol.pushPlayerIntoArray(jsonObj["playerList"]);
        this.listNum = jsonObj["playerList"].length;
    }
}
/**
 * 接收服务器推送来的逻辑帧
 * @protocol 1009/PushLogicFrame
 */
export class RecvFrame {
    /** 协议编号 */
    public msgId?: number;
    /** 序号 */
    public id?: number;
    /** 房间ID */
    public roomId?: string;
    /** 逻辑帧序号 */
    public sequenceNumber?: number;
    /** 每个逻辑帧内玩家的操作 */
    public operations?: Operation[];
    /** 每个逻辑帧内玩家的操作的数量 */
    public listNum?: number;

    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.id = jsonObj["id"];
        this.roomId = jsonObj["roomId"];
        this.sequenceNumber = jsonObj["sequenceNumber"];
        this.operations = Protocol.pushOperationIntoArray(jsonObj["operations"]);
        this.listNum = jsonObj["operations"].length;
    }
}
/**
 * 玩家的每一个操作
 */
export class Operation {
    /** 操作序号 */
    public id: number = -1;
    /** 操作类型 */
    public event: string = "";
    /** 操作指令编号 */
    public value: string = "";
    /** 玩家ID */
    public playerId: number = -1;

    constructor(id: number = -1, event: string = 'empty', value: string = '-1', playerId: number = -1) {
        this.id = id;
        this.event = event;
        this.value = value;
        this.playerId = playerId;
    }
}
/**
 * 1013 其它玩家掉线
 * @protocol 1013 otherPlayerOffline
 */
export class RemotePlayerOffline {
    /** 协议编号 */
    public msgId: number = -1;
    /** 玩家ID */
    public playerId: number = -1;
    /**
     * ctor 对收到的信息进行解析并存储
     * @param msg 收到的消息字符串
     */
    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.playerId = jsonObj["playerId"];
    }
}
/**
 * 房间历史
 */
class HistoryFrame {
    /** 序号 */
    public id: number = -1;
    /** 操作类型 */
    public action: string = '';
    /** 操作内容 */
    public content: string = '';

    constructor(id: number = -1, action: string = '', content: string = '') {
        this.id = id;
        this.action = action;
        this.content = content;
    }
}
/**
 * 1017 推送历史逻辑帧
 * @protocol 1017 / PushRoomHistroy
 */
export class RoomHistroyFrames {
    /** 协议编号 */
    public msgId: number = -1;
    /** 房间历史列表 */
    public historyFrames: HistoryFrame[] = [];
    /** 房间历史列表中有多少条历史记录 */
    public listNum: number = -1;
    /**
     * ctor 对收到的信息进行解析并存储
     * @param msg 收到的消息字符串
     */
    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.historyFrames = Protocol.pushRoomHistroyIntoArray(jsonObj["list"]);
        this.listNum = jsonObj["list"].length;
    }
}
/**
 * 1019 通知其它玩家，有玩家断线后已恢复
 * @protocol 1019 otherPlayerResumeGame
 */
export class OfflinePlayerResume {
    /** 协议编号 */
    public msgId?: number;
    /** 玩家ID */
    public playerId?: number;
    /** 房间编号 */
    public roomId?: number;
    /** 逻辑帧编号 */
    public sequenceNumber?: number;
    /**
     * ctor 对收到的信息进行解析并存储
     * @param msg 收到的消息字符串
     */
    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.playerId = jsonObj["playerId"];
        this.roomId = jsonObj["roomId"];
        this.sequenceNumber = jsonObj["sequenceNumber"];
    }
}
/**
 * 1021 房间信息
 * @protocol 1021/PushRoomInfo
 */
export class RoomInfo {
    /** 协议编号 */
    public msgId: number = -1;
    /** 逻辑帧序号 */
    public sequenceNumber: number = -1;
    /** 随机数种子 */
    public randSeek: number = -1;
    /** 玩家列表,是一个数组,内部存放了每个玩家的信息 */
    public playerList: Player[] = [];
    /** 玩家列表中有多少个玩家的信息 */
    public listNum: number = -1;
    /** 房间ID */
    public roomId: string = "";
    /**
     * ctor 对收到的信息进行解析并存储
     * @param msg 收到的消息字符串
     */
    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.sequenceNumber = jsonObj["sequenceNumber"];
        this.randSeek = jsonObj["randSeek"];
        this.playerList = Protocol.pushPlayerIntoArray(jsonObj["playerList"]);
        this.listNum = jsonObj["playerList"].length;
        if (this.listNum > 0) {
            this.roomId = this.playerList[0].roomId;
        }
        else {
            log("[Protocol]player list equals 0 !");
        }
    }
}
/**
 * 1023 开始战斗
 * @protocol  1023 / StartBattle
 */
export class StartFrameSync {
    /** 协议编号 */
    public msgId: number = -1;
    /** 逻辑帧序号 */
    public sequenceNumberStart: number = -1;
    /**
     * ctor 对收到的信息进行解析并存储
     * @param msg 收到的消息字符串
     */
    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.sequenceNumberStart = jsonObj["sequenceNumberStart"];
    }
}
/**
 * 1031 玩家匹配报名失败
 */
export class PlayerMatchSignFailed {
    /** 协议编号 */
    public msgId?: number;
    /** 玩家ID */
    public playerId?: number;
    /** 消息内容 */
    public msg?: string;
    /**
     * ctor 对收到的信息进行解析并存储
     * @param msg 收到的消息字符串
     */
    constructor(msg: string) {
        this.msgId = Number(msg.substring(0, 4));
        let jsonObj = JSON.parse(msg.slice(4));
        this.playerId = jsonObj["playerId"];
        this.msg = jsonObj["msg"];
    }
}
/**
 * 解析消息头, 解析出 同步模式，同步数据类型，sessionId，消息协议号
 * @param syncMode 同步模式
 * @param contentType 消息数据类型
 * @param msgId 消息协议号
 * @param session sessionID
 * @param msg 消息协议号 + 消息内容
 */
export class ParseMsgHeader {
    public syncMode?: SyncMode = undefined;
    public contentType?: SyncDataType = undefined;
    public msgId: number = -1;
    public session: string = '';
    public msgBody: string = '';
    constructor(msg: string) {
        this.syncMode = Number(msg.substring(0, 1));
        this.contentType = Number(msg.substring(1, 2));
        this.msgId = Number(msg.substring(2, 6));
        this.session = msg.substring(6, 38);
        this.msgBody = this.msgId.toString() + msg.slice(38);
    }
}