import { _decorator, Component, log, CCString, CCBoolean, CCInteger, game, warn } from 'cc';
import { NetSyestem } from './NetSystem';
import { MatchGroup, NetErrorType, ParseMsgHeader, InitRoom, LoginState, RemotePlayerOffline, OfflinePlayerResume, Player, Protocol, RecvFrame, RoomHistroyFrames, RoomInfo, ReconnectState, ServerPing, ServerPong, StartFrameSync, TokenState, WsURLState } from './Protocol';
const { ccclass, property } = _decorator;

/** 登陆成功 */
const LOGINSUCCESS = 200;
/** 心跳阀值标准值 */
const HEARTBEATTHREHOLDSTANDARD = 8;
/** 心跳阀值有玩家掉线下的值 */
const HEARRBEATTHREHOLDOFFLINEWAIT = 30;

/** 接收S端消息类型 */
export enum ReceivedMsgType {
    /** 登陆结果  1001/logiRes */
    initRoom = 1001,
    /** 服务器发送RTT测试 */
    serverPing = 1003,
    /** 服务器回应C端请求的RTT测试 */
    serverPong = 1005,
    /** 开始游戏前初始化 1007/enterBattle */
    matchGroup = 1007,
    /** 推送逻辑帧  1009/pushLogicFrame */
    recvFrame = 1009,
    /** 其他玩家掉线  1013/otherPlayerOffline */
    remotePlayerOffline = 1013,
    /** 推送房间历史  1017/pushRoomHistroy */
    recvHistoryFrames = 1017,
    /** 其他玩家恢复游戏  1019/otherPlayerResumeGame */
    offlinePlayerResume = 1019,
    /** 推送房间信息  1021/pushRoomInfo */
    roomInfo = 1021,
    /** 开始战斗  1023/startBattle */
    startFrameSync = 1023,
}
/** 玩家状态 */
export enum PlayerStatus {
    /** 在线 */
    online = 1,
    /** 离线 */
    offline = 2,
}
/**
 * 大厅 功能模块
 * @description 提供 登陆，匹配，取消匹配，重连申请功能
 */
@ccclass('Room')
export class Room extends Component {

    /** ip */
    @property(CCString)
    public ip?: string;
    /** port */
    @property(CCInteger)
    public port?: number;
    /** uid */
    @property(CCInteger)
    public uid?: number;
    /** 自动登陆 */
    @property(CCBoolean)
    public autoLogin?: boolean;

    // /** 使用localstorage */
    // @property(CCBoolean)
    // public useLocalStorage?: boolean;
    
    start() {
        game.addPersistRootNode(this.node);

        this.setAutoLoginMode();
        
        if (NetSyestem.getInstance().userStatus.wsURLState == WsURLState.notYet
            && NetSyestem.getInstance().userStatus.tokenState == TokenState.noToken
            && NetSyestem.getInstance().autoLogin) {
            NetSyestem.getInstance().getTokenServerURL(this.ip!, this.port!, this.uid!);
            NetSyestem.getInstance().getHttpServerURL(this.ip!, this.port!);
            NetSyestem.getInstance().sendLoginReq();
        }
    }

    update(deltaTime: number) {
        if (NetSyestem.getInstance().msgWaitingProcess()) {
            this.msgHandler(NetSyestem.getInstance().getMsg());
        }        
        NetSyestem.getInstance().heartBeat(deltaTime);

        this.lockstepSync(deltaTime);
    }

    onDestroy() {
        NetSyestem.desInstance();
    }

    private setAutoLoginMode(): void {
        if(this.autoLogin == undefined) { return; }
        NetSyestem.getInstance().autoLogin = this.autoLogin;
    }   

    private msgHandler(msg: string): void {
        let netMsg = new ParseMsgHeader(msg);
        switch (netMsg.msgId) {
            case ReceivedMsgType.initRoom: 
                NetSyestem.getInstance().resetHeartBeatTimer();
                NetSyestem.getInstance().session = netMsg.session;
                let initRoom = new InitRoom(netMsg.msgBody);
                if (initRoom.code == LOGINSUCCESS) {
                    NetSyestem.getInstance().localPlayerId = initRoom.player.id;
                    NetSyestem.getInstance().userStatus.loginState = LoginState.aleadyLogin;
                    // 不需要重连
                    if (initRoom.player.roomId == undefined || initRoom.player.roomId == "" || initRoom.player.roomId == null) {
                        NetSyestem.getInstance().dispatchJoinRoom(initRoom);
                        if (this.autoLogin) {
                            NetSyestem.getInstance().sendMatchReq();
                        }
                    }
                    // 需要重连
                    else {
                        NetSyestem.getInstance().userStatus.reconnectState = ReconnectState.can;
                        NetSyestem.getInstance().roomId = initRoom.player.roomId;
                        NetSyestem.getInstance().sendRejoinRoomReq();
                    }
                }
                // 其他code
                else {
                    warn("[Login] loginRes code error :" + initRoom.code);
                    NetSyestem.getInstance().dispatchNetError(NetErrorType.joinRoomFailed);
                }
                break;
            case ReceivedMsgType.matchGroup: 
                NetSyestem.getInstance().resetHeartBeatTimer();
                let matchGroup = new MatchGroup(netMsg.msgBody);
                log("[Room]readyFrameSync |", "msgId:" + matchGroup.msgId, "roomId:" + matchGroup.roomId);
                NetSyestem.getInstance().roomId = matchGroup.roomId;
                this.initUserLists(matchGroup.playerList);
                NetSyestem.getInstance().dispatchMatchGroup(matchGroup);
                break;
            case ReceivedMsgType.roomInfo:
                NetSyestem.getInstance().resetHeartBeatTimer();
                let roomInfo = new RoomInfo(netMsg.msgBody);
                NetSyestem.getInstance().roomId = roomInfo.roomId;
                this.initUserLists(roomInfo.playerList);
                NetSyestem.getInstance().disptachRejoinRoom(roomInfo);
                NetSyestem.getInstance().requestRoomHistory();
                log("[Room] roomInfo |", "msgId:" + roomInfo.msgId, "roomId:" + roomInfo.roomId, "sequenceNumber:" + roomInfo.sequenceNumber);
                // 该消息会在玩家重新加入Room时和接收全部Room history frames后收到，这里是接收全部Room history frames后判断是否其他玩家都正常在线
                if (NetSyestem.getInstance().userStatus.reconnectState == ReconnectState.recovered) {
                    let listNum = roomInfo.listNum;
                    for (let index = 0; index < listNum; index++) {
                        if (roomInfo.playerList == undefined) { return; };
                        const element = roomInfo.playerList[index];
                        if (element.status == PlayerStatus.offline) {
                            NetSyestem.getInstance().addOfflineUserList(element.id);
                            log("[Group]RoomInfo |", "playerId:" + element.id + " also offline ,plz wait reconnect ! ");
                        }
                    }
                    // 玩家全部在线，继续游戏
                    if (NetSyestem.getInstance().offlineUserListIsEmpty()) {
                        log("[Group]RoomInfo |" + "all player online , game continue !");
                        NetSyestem.getInstance().allowSyncUserCommands = true;
                        NetSyestem.getInstance().dispatchResumeFrameSync();
                    }
                }
                break;
            case ReceivedMsgType.recvHistoryFrames:
                NetSyestem.getInstance().resetHeartBeatTimer();
                NetSyestem.getInstance().allowHeartBeat = false;
                let roomHistroyFrames = new RoomHistroyFrames(netMsg.msgBody);
                let roomHistoryLength = roomHistroyFrames.historyFrames.length;
                for (let index = 0; index < roomHistoryLength; index++) {
                    if (roomHistroyFrames.historyFrames == undefined) { continue; };
                    const roomHistory = roomHistroyFrames.historyFrames[index];
                    if (roomHistory.action == "pushLogicFrame") {
                        // 这里需要再解析一次 JSON string的原因是，S端发过来的这个内容经过一次json.parse后依旧是JSON string
                        const data = JSON.parse(roomHistory.content);
                        if (NetSyestem.getInstance().frameSyncSequenceNumber != data["sequenceNumber"]) {
                            NetSyestem.getInstance().frameSyncSequenceNumber = data["sequenceNumber"];
                        }
                        let operationLength = data["operations"].length;
                        for (let index = 0; index < operationLength; index++) {
                            if (data["operations"] == undefined) { continue; };
                            const operation = data["operations"][index];
                            log("[Group]pushRoomHistroy |", "playerID:", operation.playerId, "move value:", operation.value);
                            NetSyestem.getInstance().dispatchFrame(operation);
                        }
                    }
                }
                NetSyestem.getInstance().userStatus.reconnectState = ReconnectState.recovering;
                NetSyestem.getInstance().dispatchRoomHistoryFrames(roomHistroyFrames);
                break;
            case ReceivedMsgType.serverPing:
                let serverPingMsg = new ServerPing(netMsg.msgBody);
                NetSyestem.getInstance().sendMsg(Protocol.clientPong(serverPingMsg.addTime, serverPingMsg.serverResponseTime, serverPingMsg.rttTimeout, serverPingMsg.rttTimes));
                break;
            case ReceivedMsgType.serverPong:
                let serverPongMsg = new ServerPong(netMsg.msgBody);
                NetSyestem.getInstance().testRTT(serverPongMsg);
                break;
            case ReceivedMsgType.recvFrame: // S端推送逻辑帧
                NetSyestem.getInstance().resetHeartBeatTimer();
                let recvFrame = new RecvFrame(netMsg.msgBody);
                // 当前收到的逻辑帧号 等于 当前保存的逻辑帧号+1，说明收到的是下一个逻辑帧的数据
                if (recvFrame.sequenceNumber == NetSyestem.getInstance().frameSyncSequenceNumber + 1) {
                    NetSyestem.getInstance().frameSyncSequenceNumber = recvFrame.sequenceNumber;
                    NetSyestem.getInstance().allowSyncUserCommands = true;
                    if(recvFrame.operations == undefined){ return; }
                    let operationsLength = recvFrame.operations.length;
                    for (let index = 0; index < operationsLength; index++) {
                        if (recvFrame.operations == undefined) { continue; }
                        const operation = recvFrame.operations[index];
                        NetSyestem.getInstance().dispatchFrame(operation);
                        // log("[Group]pushLogicFrame - operation|", "playerId:" + operation.playerId, "event:" + operation.event, "value:" + operation.value);
                    }
                }
                else {  // 玩家收到的逻辑帧序号对不上
                    log("[Game]Received error logic frame :" + recvFrame.sequenceNumber,
                        " Current logic frame in client :" + NetSyestem.getInstance().frameSyncSequenceNumber);
                    NetSyestem.getInstance().dispatchRecvUnknowFrame(recvFrame);
                }
                break;
            case ReceivedMsgType.startFrameSync:
                NetSyestem.getInstance().resetHeartBeatTimer();
                let startFrameSync = new StartFrameSync(netMsg.msgBody);
                log("[Group]startFrame |", "msgId:" + startFrameSync.msgId, "sequenceNumberStart:" + startFrameSync.sequenceNumberStart);
                NetSyestem.getInstance().frameSyncSequenceNumber = startFrameSync.sequenceNumberStart;
                NetSyestem.getInstance().allowSyncUserCommands = true;
                NetSyestem.getInstance().dispatchStartFrameSync(startFrameSync);
                NetSyestem.getInstance().sendMsg(Protocol.clientPing());
                break;
            case ReceivedMsgType.offlinePlayerResume:
                NetSyestem.getInstance().resetHeartBeatTimer();
                let offlinePlayerResume = new OfflinePlayerResume(netMsg.msgBody);
                log("[Group]otherPlayerResumeGame |", "msgId:" + offlinePlayerResume.msgId, "playerId:" + offlinePlayerResume.playerId, "roomId:" + offlinePlayerResume.roomId, "sequenceNumber:" + offlinePlayerResume.sequenceNumber);
                if(offlinePlayerResume.sequenceNumber == undefined) { return; }
                NetSyestem.getInstance().frameSyncSequenceNumber = offlinePlayerResume.sequenceNumber;
                if(offlinePlayerResume.playerId == undefined) { return; }
                NetSyestem.getInstance().queryOfflineUserList(offlinePlayerResume.playerId);
                NetSyestem.getInstance().dispatchOfflinePlayerResume(offlinePlayerResume);
                if (NetSyestem.getInstance().offlineUserListIsEmpty()) {
                    NetSyestem.getInstance().allowSyncUserCommands = true;
                    NetSyestem.getInstance().heartBeatThreholdValue = HEARTBEATTHREHOLDSTANDARD;
                    NetSyestem.getInstance().dispatchResumeFrameSync();
                }
                break;
            case ReceivedMsgType.remotePlayerOffline: 
                NetSyestem.getInstance().resetHeartBeatTimer();
                let remotePlayerOffline = new RemotePlayerOffline(netMsg.msgBody);
                log("[Group]remotePlayerOffline |", "msgId:" + remotePlayerOffline.msgId, "playerId:" + remotePlayerOffline.playerId);
                NetSyestem.getInstance().addOfflineUserList(remotePlayerOffline.playerId);
                NetSyestem.getInstance().heartBeatThreholdValue = HEARRBEATTHREHOLDOFFLINEWAIT;
                NetSyestem.getInstance().dispatchRemotePlayerOffline(remotePlayerOffline);
                break;
            default:
                var json = JSON.parse(msg.slice(38));
                log("[Room]Receive unkonw msg ->" + json);
                break;
        }
    }
    /** 初始化玩家指令列表 */
    private initUserLists(players: Player[]): void {
        let playerLength = players.length;
        for (let index = 0; index < playerLength; index++) {
            if(players == undefined){ continue; };
            const player = players[index];
            NetSyestem.getInstance().addOnlineUserList(player.id);
            if (player.status == PlayerStatus.offline) {
                NetSyestem.getInstance().addOfflineUserList(player.id);
            }
            log("[Room]initAndSetUserLists |", "playerId:", player.id, "playerStatus:", player.status);
        }
    }
    /** lockstep sync 计时器 */
    private syncTimer: number = 0;
    /** operator 序号 */
    private operationsId: number = 0;
    /**
     * lockstep sync
     */
    private lockstepSync(dt: number): void {
        // 如果不能同步操作，直接返回
        if (!NetSyestem.getInstance().allowSyncUserCommands)
            return;
        this.syncTimer += dt;
        // 大于同步时间间隔，直接锁帧
        if (this.syncTimer > NetSyestem.getInstance().logicFPS) {
            // 重置同步间隔计时器
            this.syncTimer = 0;
            // 进入lock状态
            NetSyestem.getInstance().allowSyncUserCommands = false;
            let num = NetSyestem.getInstance().usrCommandsPerFrameSyncLength();
            if (num > 0) {
                let msgContent: object[] = [];
                // 取出操作指令缓存队列里全部操作，粘合成一个字符串
                for (let index = 0; index < num; index++) {
                    let commandIndex = NetSyestem.getInstance().getIndexedCommand(index);
                    let perMsg = Protocol.operation(NetSyestem.getInstance().localPlayerId,"move",commandIndex.toString());
                    msgContent.push(perMsg);
                }
                NetSyestem.getInstance().sendMsg(Protocol.playerOperations(NetSyestem.getInstance().roomId, NetSyestem.getInstance().frameSyncSequenceNumber, msgContent, ++this.operationsId));
                NetSyestem.getInstance().emptySyncCommandsPerFrameSync();
                //log("[Game]send player command :" + msgContent + "|sequence number : " + NetSyestem.getInstance().sequenceNumber);
            }
            else {
                // 玩家在该logic frame中没有操作，发送空操作指令
                let obj = Protocol.operation(NetSyestem.getInstance().localPlayerId);
                let msgContent: object[] = [];
                msgContent.push(obj);
                NetSyestem.getInstance().sendMsg(Protocol.playerOperations(NetSyestem.getInstance().roomId, NetSyestem.getInstance().frameSyncSequenceNumber, msgContent, ++this.operationsId));
                //log("[Game]send empty command : " + msgContent + "|sequence number : " + NetSyestem.getInstance().sequenceNumber + "/unixstamp :" + NetSyestem.getInstance().getUnixStamp());
            }
        }
    }
}

/**
 * [1] Class member could be defined like this.
 * [2] Use `property` decorator if your want the member to be serializable.
 * [3] Your initialization goes here.
 * [4] Your update function goes here.
 *
 * Learn more about scripting: https://docs.cocos.com/creator/3.0/manual/en/scripting/
 * Learn more about CCClass: https://docs.cocos.com/creator/3.0/manual/en/scripting/ccclass.html
 * Learn more about life-cycle callbacks: https://docs.cocos.com/creator/3.0/manual/en/scripting/life-cycle-callbacks.html
 */
